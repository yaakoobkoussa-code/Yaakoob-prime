import React, { useCallback, useEffect, useState } from 'react';
import { Globe, Link2, RefreshCw, Save } from 'lucide-react';
import { ToggleSwitch } from '../../components/common/ToggleSwitch';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { ServerId } from '../../shared/types';
import { formatDateTime } from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface ServerRow {
  id: ServerId;
  name: string;
  flag: string;
  code: string;
  enabled: number;
  status: 'operational' | 'high_load' | 'maintenance';
  routing_note: string;
  sort_order: number;
  updated_at: string | null;
}

export const ServerManagementPage: React.FC<{
  onOpenUrls?: () => void;
}> = ({ onOpenUrls }) => {
  const { can } = useAdminAuth();
  const { addToast } = useToast();
  const canManage = can('servers.manage');

  const [servers, setServers] = useState<ServerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [drafts, setDrafts] = useState<
    Record<string, { name: string; status: ServerRow['status']; routingNote: string }>
  >({});
  const [savingId, setSavingId] = useState<string | null>(null);

  const loadServers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{ servers: ServerRow[] }>('/api/admin/servers', {
        scope: 'admin',
      });
      setServers(res.servers);
      const nextDrafts: Record<
        string,
        { name: string; status: ServerRow['status']; routingNote: string }
      > = {};
      for (const s of res.servers) {
        nextDrafts[s.id] = {
          name: s.name,
          status: s.status,
          routingNote: s.routing_note ?? '',
        };
      }
      setDrafts(nextDrafts);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to load servers',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    loadServers();
  }, [loadServers]);

  const handleToggleEnabled = async (srv: ServerRow) => {
    if (!canManage) return;
    setSavingId(srv.id);
    try {
      await apiRequest(`/api/admin/servers/${srv.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: { enabled: srv.enabled !== 1 },
      });
      addToast({
        type: 'success',
        title: `${srv.name} ${srv.enabled === 1 ? 'disabled' : 'enabled'}`,
      });
      await loadServers();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to update server',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setSavingId(null);
    }
  };

  const handleSave = async (srv: ServerRow) => {
    if (!canManage) return;
    const draft = drafts[srv.id];
    if (!draft) return;
    setSavingId(srv.id);
    try {
      await apiRequest(`/api/admin/servers/${srv.id}`, {
        method: 'PATCH',
        scope: 'admin',
        body: {
          name: draft.name.trim() || srv.name,
          status: draft.status,
          routingNote: draft.routingNote.trim(),
        },
      });
      addToast({ type: 'success', title: `${srv.name} configuration saved` });
      await loadServers();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to save server',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Server Management</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Configure availability, operational status, and routing labels for all 5 official regions.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {onOpenUrls && can('urls.manage') && (
            <button
              type="button"
              onClick={onOpenUrls}
              className="min-h-[40px] px-3.5 rounded-xl bg-purple-600/15 hover:bg-purple-600/25 border border-purple-500/30 text-xs font-semibold text-purple-200 inline-flex items-center gap-2"
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>Subscription URLs (10)</span>
            </button>
          )}
          <button
            type="button"
            onClick={loadServers}
            className="min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {loading && servers.length === 0 ? (
        <p className="text-sm text-zinc-400">Loading server regions...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {servers.map((srv) => {
            const draft = drafts[srv.id] ?? {
              name: srv.name,
              status: srv.status,
              routingNote: srv.routing_note ?? '',
            };
            const isEnabled = srv.enabled === 1;
            const isSaving = savingId === srv.id;

            return (
              <section
                key={srv.id}
                className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-11 h-11 rounded-xl bg-[#07070A] border border-zinc-800 flex items-center justify-center text-xl shrink-0">
                      {srv.flag}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h2 className="font-display text-base font-semibold text-white truncate">
                          {srv.name}
                        </h2>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/5 text-zinc-400 border border-zinc-800">
                          {srv.code}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-500 mt-0.5">
                        {srv.updated_at
                          ? `Updated ${formatDateTime(srv.updated_at)}`
                          : 'Default server configuration'}
                      </p>
                    </div>
                  </div>

                  <ToggleSwitch
                    checked={isEnabled}
                    disabled={!canManage || isSaving}
                    label={`Enable ${srv.name}`}
                    onChange={() => handleToggleEnabled(srv)}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1.5">
                      Display Name
                    </label>
                    <input
                      type="text"
                      value={draft.name}
                      disabled={!canManage}
                      onChange={(e) =>
                        setDrafts((prev) => ({
                          ...prev,
                          [srv.id]: { ...draft, name: e.target.value },
                        }))
                      }
                      className="w-full h-10 px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-100 focus:outline-none focus:border-purple-500 disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1.5">
                      Status
                    </label>
                    <select
                      value={draft.status}
                      disabled={!canManage}
                      onChange={(e) =>
                        setDrafts((prev) => ({
                          ...prev,
                          [srv.id]: {
                            ...draft,
                            status: e.target.value as ServerRow['status'],
                          },
                        }))
                      }
                      className="w-full h-10 px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-100 focus:outline-none focus:border-purple-500 disabled:opacity-60"
                    >
                      <option value="operational">Operational</option>
                      <option value="high_load">High Load</option>
                      <option value="maintenance">Maintenance</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-zinc-400 mb-1.5">
                    Routing Note
                  </label>
                  <input
                    type="text"
                    value={draft.routingNote}
                    disabled={!canManage}
                    placeholder="e.g. Low-latency Southeast Asia relay"
                    onChange={(e) =>
                      setDrafts((prev) => ({
                        ...prev,
                        [srv.id]: { ...draft, routingNote: e.target.value },
                      }))
                    }
                    className="w-full h-10 px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-purple-500 disabled:opacity-60"
                  />
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-zinc-800/70">
                  <div className="inline-flex items-center gap-1.5 text-xs text-zinc-400">
                    <Globe className="w-3.5 h-3.5 text-purple-400" />
                    <span>{isEnabled ? 'Visible to users' : 'Hidden / blocked for users'}</span>
                  </div>

                  {canManage && (
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => handleSave(srv)}
                      className="min-h-[38px] px-3.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-xs font-semibold text-white inline-flex items-center gap-1.5 transition-colors"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSaving ? 'Saving...' : 'Save'}</span>
                    </button>
                  )}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
};
