import React, { useState } from 'react';
import { KeyRound, RotateCcw, Save, ShieldCheck, Smartphone, Trash2 } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { ServerRegionId } from '../../types';
import { BrandLogo } from '../common/BrandLogo';
import { ToggleSwitch } from '../common/ToggleSwitch';

export const WebsiteSettings: React.FC = () => {
  const {
    settings,
    servers,
    adminDevices,
    updateSettings,
    removeAdminDevice,
    resetDemoData,
    addToast,
  } = useAppState();

  const [titleDraft, setTitleDraft] = useState(settings.websiteTitle);
  const [messageDraft, setMessageDraft] = useState(settings.systemMessage);
  const [twoFactorVerifyInput, setTwoFactorVerifyInput] = useState('');

  const handleSaveGeneral = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      websiteTitle: titleDraft.trim() || 'PRIME WIRE PRO',
      systemMessage: messageDraft,
    });
  };

  const handleSimulate2FA = (e: React.FormEvent) => {
    e.preventDefault();
    if (twoFactorVerifyInput.length !== 6) {
      addToast({
        type: 'warning',
        title: 'Enter 6-digit code',
        description: 'Provide any 6 digits to test the Phase 1 2FA verification flow.',
      });
      return;
    }
    updateSettings({ twoFactorEnabled: true });
    setTwoFactorVerifyInput('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">
          Website & Security Settings
        </h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Configure platform branding, maintenance mode, default server, 2FA, and admin sessions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Website Settings */}
        <form
          onSubmit={handleSaveGeneral}
          className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 sm:p-6 space-y-5"
        >
          <h2 className="font-display text-base font-semibold text-white">Website Settings</h2>

          <div className="flex items-center gap-4 rounded-xl bg-[#07070A] border border-zinc-800 p-4">
            <BrandLogo size="lg" glow={false} />
            <div>
              <p className="text-xs font-medium text-white">Official Platform Logo</p>
              <p className="text-xs text-zinc-400 mt-0.5">
                Locked to the official PRIME WIRE PRO anime emblem.
              </p>
            </div>
          </div>

          <div>
            <label htmlFor="site-title" className="block text-xs font-medium text-zinc-300 mb-1.5">
              Website Title
            </label>
            <input
              id="site-title"
              type="text"
              value={titleDraft}
              onChange={(e) => setTitleDraft(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          <div>
            <label htmlFor="sys-msg" className="block text-xs font-medium text-zinc-300 mb-1.5">
              System Announcement Message
            </label>
            <input
              id="sys-msg"
              type="text"
              value={messageDraft}
              onChange={(e) => setMessageDraft(e.target.value)}
              placeholder="Leave empty to hide client banner"
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div>
            <label htmlFor="def-server" className="block text-xs font-medium text-zinc-300 mb-1.5">
              Default Server Region
            </label>
            <select
              id="def-server"
              value={settings.defaultServerId}
              onChange={(e) =>
                updateSettings({ defaultServerId: e.target.value as ServerRegionId })
              }
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
            >
              {servers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.flag} {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between gap-4 rounded-xl bg-[#07070A] border border-zinc-800 px-4 py-3">
            <div>
              <p className="text-xs font-medium text-white">Maintenance Mode</p>
              <p className="text-[11px] text-zinc-400">
                Pauses client sign-in on the login page
              </p>
            </div>
            <ToggleSwitch
              checked={settings.maintenanceMode}
              label="Toggle maintenance mode"
              onChange={() => updateSettings({ maintenanceMode: !settings.maintenanceMode })}
            />
          </div>

          <button
            type="submit"
            className="w-full min-h-[46px] rounded-xl bg-purple-600 hover:bg-purple-500 text-sm font-semibold text-white inline-flex items-center justify-center gap-2 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Website Settings</span>
          </button>
        </form>

        {/* Security Settings */}
        <div className="space-y-6">
          {/* 2FA & Session Settings */}
          <section className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 sm:p-6 space-y-5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
                <h2 className="font-display text-base font-semibold text-white">
                  Security & Session Settings
                </h2>
              </div>
              <span
                className={`text-xs font-medium ${
                  settings.twoFactorEnabled ? 'text-emerald-400' : 'text-zinc-400'
                }`}
              >
                {settings.twoFactorEnabled ? '2FA Enabled' : '2FA Disabled'}
              </span>
            </div>

            <div className="flex items-center justify-between gap-4 rounded-xl bg-[#07070A] border border-zinc-800 px-4 py-3">
              <div>
                <p className="text-xs font-medium text-white">Two-Factor Authentication (2FA)</p>
                <p className="text-[11px] text-zinc-400">TOTP requirement simulation</p>
              </div>
              <ToggleSwitch
                checked={settings.twoFactorEnabled}
                label="Toggle two-factor authentication"
                onChange={() =>
                  updateSettings({ twoFactorEnabled: !settings.twoFactorEnabled })
                }
              />
            </div>

            <form onSubmit={handleSimulate2FA} className="space-y-2">
              <label htmlFor="totp-sim" className="block text-xs font-medium text-zinc-300">
                Verify TOTP Setup (Demo Key: <span className="font-mono">PMWR-TOTP-DEMO</span>)
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1 flex items-center">
                  <KeyRound className="w-4 h-4 text-zinc-500 absolute left-3 pointer-events-none" />
                  <input
                    id="totp-sim"
                    type="text"
                    maxLength={6}
                    inputMode="numeric"
                    value={twoFactorVerifyInput}
                    onChange={(e) => setTwoFactorVerifyInput(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    className="w-full min-h-[42px] pl-9 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs font-mono tracking-widest text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <button
                  type="submit"
                  className="min-h-[42px] px-4 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-white"
                >
                  Verify
                </button>
              </div>
            </form>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="sess-timeout"
                  className="block text-xs font-medium text-zinc-300 mb-1.5"
                >
                  Session Timeout (Minutes)
                </label>
                <select
                  id="sess-timeout"
                  value={settings.sessionTimeoutMinutes}
                  onChange={(e) =>
                    updateSettings({ sessionTimeoutMinutes: Number(e.target.value) })
                  }
                  className="w-full min-h-[42px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-white"
                >
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={60}>60 minutes</option>
                  <option value={240}>4 hours</option>
                </select>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-xl bg-[#07070A] border border-zinc-800 px-3.5 py-2.5">
                <span className="text-xs text-zinc-300">Single Admin Session</span>
                <ToggleSwitch
                  checked={settings.singleAdminSession}
                  label="Toggle single admin session"
                  onChange={() =>
                    updateSettings({ singleAdminSession: !settings.singleAdminSession })
                  }
                />
              </div>
            </div>
          </section>

          {/* Admin Device Management */}
          <section className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-white">
                Admin Device Management
              </h2>
              <button
                type="button"
                onClick={resetDemoData}
                className="min-h-[34px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-300 inline-flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Demo State</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {adminDevices.map((adm) => (
                <div
                  key={adm.id}
                  className="rounded-xl bg-[#07070A] border border-zinc-800 px-4 py-3 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Smartphone className="w-4 h-4 text-purple-400 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">
                        {adm.label} {adm.current ? '(Current)' : ''}
                      </p>
                      <p className="text-[11px] text-zinc-400 truncate">
                        {adm.browser} · {adm.lastSeen}
                      </p>
                    </div>
                  </div>
                  {!adm.current && (
                    <button
                      type="button"
                      onClick={() => removeAdminDevice(adm.id)}
                      aria-label={`Revoke ${adm.label}`}
                      className="min-w-[36px] min-h-[36px] rounded-lg hover:bg-rose-500/15 text-zinc-500 hover:text-rose-400 flex items-center justify-center shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
