import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  INITIAL_ADMIN_DEVICES,
  INITIAL_DEVICES,
  INITIAL_DISTRIBUTORS,
  INITIAL_FEATURES,
  INITIAL_KEYS,
  INITIAL_SECURITY_LOGS,
  INITIAL_SERVERS,
  INITIAL_SETTINGS,
  INITIAL_SUBSCRIPTION_URLS,
} from '../data/demoData';
import {
  ActivationRule,
  AdminDevice,
  Distributor,
  FeatureConfig,
  FeatureId,
  KeyStatus,
  ProductKeyRecord,
  RegisteredDevice,
  SecurityLogEntry,
  ServerRegion,
  ServerRegionId,
  SubscriptionUrlSlot,
  ToastMessage,
  UserSession,
  WebsiteSettings,
} from '../types';
import {
  detectClientDeviceInfo,
  generateDemoProductKey,
  maskProductKey,
  PRODUCT_KEY_REGEX,
} from '../utils/formatters';

interface PersistedState {
  keys: ProductKeyRecord[];
  servers: ServerRegion[];
  features: FeatureConfig[];
  subscriptionUrls: SubscriptionUrlSlot[];
  distributors: Distributor[];
  devices: RegisteredDevice[];
  securityLogs: SecurityLogEntry[];
  adminDevices: AdminDevice[];
  settings: WebsiteSettings;
  userSession: UserSession | null;
  isAdminAuthenticated: boolean;
}

const STORAGE_KEY = 'prime_wire_pro_phase1_demo_v1';

function loadInitialState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<PersistedState>;
      return {
        keys: parsed.keys && parsed.keys.length > 0 ? parsed.keys : INITIAL_KEYS,
        servers: parsed.servers && parsed.servers.length === 5 ? parsed.servers : INITIAL_SERVERS,
        features: parsed.features && parsed.features.length === 2 ? parsed.features : INITIAL_FEATURES,
        subscriptionUrls:
          parsed.subscriptionUrls && parsed.subscriptionUrls.length === 10
            ? parsed.subscriptionUrls
            : INITIAL_SUBSCRIPTION_URLS,
        distributors: parsed.distributors ?? INITIAL_DISTRIBUTORS,
        devices: parsed.devices ?? INITIAL_DEVICES,
        securityLogs: parsed.securityLogs ?? INITIAL_SECURITY_LOGS,
        adminDevices: parsed.adminDevices ?? INITIAL_ADMIN_DEVICES,
        settings: parsed.settings ? { ...INITIAL_SETTINGS, ...parsed.settings } : INITIAL_SETTINGS,
        userSession: parsed.userSession ?? null,
        isAdminAuthenticated: parsed.isAdminAuthenticated ?? false,
      };
    }
  } catch {
    // Fallback to defaults if storage is unavailable
  }
  return {
    keys: INITIAL_KEYS,
    servers: INITIAL_SERVERS,
    features: INITIAL_FEATURES,
    subscriptionUrls: INITIAL_SUBSCRIPTION_URLS,
    distributors: INITIAL_DISTRIBUTORS,
    devices: INITIAL_DEVICES,
    securityLogs: INITIAL_SECURITY_LOGS,
    adminDevices: INITIAL_ADMIN_DEVICES,
    settings: INITIAL_SETTINGS,
    userSession: null,
    isAdminAuthenticated: false,
  };
}

export interface GenerateKeysInput {
  count: number;
  durationDays: number;
  deviceLimit: number;
  allowedServers: ServerRegionId[];
  allowedFeatures: FeatureId[];
  distributorId: string;
  activationRule: ActivationRule;
  customKey?: string;
}

export interface AddDistributorInput {
  name: string;
  handle: string;
  email: string;
  generationLimit: number;
  allowedServers: ServerRegionId[];
  allowedFeatures: FeatureId[];
}

interface AppStateContextValue extends PersistedState {
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  dismissToast: (id: string) => void;
  loginUser: (rawKey: string, rememberDevice: boolean) => Promise<{ ok: boolean; message?: string }>;
  logoutUser: () => void;
  selectUserServer: (serverId: ServerRegionId) => void;
  toggleUserFeature: (featureId: FeatureId) => void;
  loginAdmin: (username: string, password: string) => Promise<{ ok: boolean; message?: string }>;
  logoutAdmin: () => void;
  generateKeys: (input: GenerateKeysInput) => ProductKeyRecord[];
  updateKeyStatus: (keyId: string, status: KeyStatus) => void;
  deleteKey: (keyId: string) => void;
  updateSubscriptionUrl: (slotId: string, url: string) => void;
  updateServer: (serverId: ServerRegionId, patch: Partial<ServerRegion>) => void;
  updateFeature: (featureId: FeatureId, patch: Partial<FeatureConfig>) => void;
  addDistributor: (input: AddDistributorInput) => void;
  toggleDistributorStatus: (distributorId: string) => void;
  updateDistributor: (distributorId: string, patch: Partial<Distributor>) => void;
  deleteDistributor: (distributorId: string) => void;
  updateDeviceStatus: (deviceId: string, status: RegisteredDevice['status']) => void;
  unbindDevice: (deviceId: string) => void;
  updateSettings: (patch: Partial<WebsiteSettings>) => void;
  removeAdminDevice: (deviceId: string) => void;
  resetDemoData: () => void;
}

const AppStateContext = createContext<AppStateContextValue | null>(null);

export const AppStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<PersistedState>(loadInitialState);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage quota errors
    }
  }, [state]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const addToast = useCallback(
    (toast: Omit<ToastMessage, 'id'>) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
      setTimeout(() => {
        dismissToast(id);
      }, 4000);
    },
    [dismissToast]
  );

  const appendLog = useCallback(
    (
      logs: SecurityLogEntry[],
      entry: Omit<SecurityLogEntry, 'id' | 'timestamp'>
    ): SecurityLogEntry[] => {
      const next: SecurityLogEntry = {
        ...entry,
        id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toISOString(),
      };
      return [next, ...logs].slice(0, 60);
    },
    []
  );

  const loginUser = useCallback(
    async (rawKey: string, rememberDevice: boolean) => {
      const normalized = rawKey.trim().toUpperCase();
      await new Promise((r) => setTimeout(r, 650));

      if (!PRODUCT_KEY_REGEX.test(normalized)) {
        return {
          ok: false,
          message: 'Invalid format. Product keys must match PMWR-XXXX-XXXX-XXXX.',
        };
      }

      if (state.settings.maintenanceMode) {
        return {
          ok: false,
          message: 'Service is currently in maintenance mode. Check back shortly.',
        };
      }

      const found = state.keys.find((k) => k.key === normalized);
      if (!found) {
        return {
          ok: false,
          message: 'Product key not recognized. Please verify your key and try again.',
        };
      }

      if (found.status === 'revoked') {
        return { ok: false, message: 'This product key has been revoked by an administrator.' };
      }
      if (found.status === 'suspended') {
        return { ok: false, message: 'This product key is temporarily suspended.' };
      }
      if (found.status === 'expired' || new Date(found.expiresAt).getTime() <= Date.now()) {
        return { ok: false, message: 'This product key subscription has expired.' };
      }

      const { deviceLabel, platformName } = detectClientDeviceInfo();
      const defaultAllowed = found.allowedServers.includes(state.settings.defaultServerId)
        ? state.settings.defaultServerId
        : found.allowedServers[0] ?? 'singapore';

      const nowIso = new Date().toISOString();
      const updatedKeys = state.keys.map((k) => {
        if (k.id !== found.id) return k;
        const shouldActivate = !k.activatedAt;
        const expiresAt = shouldActivate
          ? new Date(Date.now() + k.durationDays * 86_400_000).toISOString()
          : k.expiresAt;
        return {
          ...k,
          activatedAt: k.activatedAt ?? nowIso,
          expiresAt,
          devicesUsed: Math.max(1, k.devicesUsed),
          lastUsedDevice: `${deviceLabel} · ${platformName}`,
        };
      });

      const session: UserSession = {
        keyRecordId: found.id,
        productKey: found.key,
        rememberDevice,
        selectedServerId: defaultAllowed,
        activeFeatureId: null,
        deviceLabel,
        platformName,
        signedInAt: nowIso,
      };

      setState((prev) => ({
        ...prev,
        keys: updatedKeys,
        userSession: session,
        securityLogs: appendLog(prev.securityLogs, {
          event: 'Client session authenticated (Demo)',
          actor: maskProductKey(found.key),
          target: `${defaultAllowed.toUpperCase()} Node`,
          severity: 'info',
          region: defaultAllowed.charAt(0).toUpperCase() + defaultAllowed.slice(1),
        }),
      }));

      addToast({
        type: 'success',
        title: 'Access granted',
        description: 'Phase 1 demonstration session initialized.',
      });

      return { ok: true };
    },
    [state.keys, state.settings.defaultServerId, state.settings.maintenanceMode, appendLog, addToast]
  );

  const logoutUser = useCallback(() => {
    setState((prev) => ({
      ...prev,
      userSession: null,
    }));
    addToast({
      type: 'info',
      title: 'Signed out',
      description: 'Your demonstration session has been closed.',
    });
  }, [addToast]);

  const selectUserServer = useCallback(
    (serverId: ServerRegionId) => {
      setState((prev) => {
        if (!prev.userSession) return prev;
        const target = prev.servers.find((s) => s.id === serverId);
        if (!target) return prev;
        if (target.status === 'maintenance') {
          addToast({
            type: 'warning',
            title: `${target.name} unavailable`,
            description: 'This server is currently set to maintenance in Admin.',
          });
          return prev;
        }
        addToast({
          type: 'success',
          title: `Region set to ${target.name}`,
          description: `${target.flag} ${target.code} selected for demonstration.`,
        });
        return {
          ...prev,
          userSession: {
            ...prev.userSession,
            selectedServerId: serverId,
          },
        };
      });
    },
    [addToast]
  );

  const toggleUserFeature = useCallback(
    (featureId: FeatureId) => {
      setState((prev) => {
        if (!prev.userSession) return prev;
        const feature = prev.features.find((f) => f.id === featureId);
        const keyRecord = prev.keys.find((k) => k.id === prev.userSession?.keyRecordId);
        if (!feature || !keyRecord) return prev;

        if (!feature.globallyEnabled) {
          addToast({
            type: 'error',
            title: `${feature.title} disabled`,
            description: 'This feature is disabled globally in Admin settings.',
          });
          return prev;
        }

        if (!keyRecord.allowedFeatures.includes(featureId)) {
          addToast({
            type: 'warning',
            title: 'Authorization required',
            description: `Your current key is not authorized for ${feature.title}.`,
          });
          return prev;
        }

        const isCurrentlyActive = prev.userSession.activeFeatureId === featureId;
        const nextActive: FeatureId | null = isCurrentlyActive ? null : featureId;

        addToast({
          type: nextActive ? 'success' : 'info',
          title: nextActive ? `${feature.title} enabled` : `${feature.title} disabled`,
          description: nextActive
            ? 'Only one profile can remain active at a time.'
            : 'All feature profiles are currently inactive.',
        });

        return {
          ...prev,
          userSession: {
            ...prev.userSession,
            activeFeatureId: nextActive,
          },
        };
      });
    },
    [addToast]
  );

  const loginAdmin = useCallback(
    async (username: string, password: string) => {
      await new Promise((r) => setTimeout(r, 550));
      if (!username.trim() || password.trim().length < 4) {
        return {
          ok: false,
          message: 'Enter an admin identifier and at least 4 characters for the demo password.',
        };
      }
      setState((prev) => ({
        ...prev,
        isAdminAuthenticated: true,
        securityLogs: appendLog(prev.securityLogs, {
          event: 'Admin console sign-in (Simulated)',
          actor: username.trim(),
          target: 'Administration Panel',
          severity: 'info',
          region: 'Global',
        }),
      }));
      addToast({
        type: 'success',
        title: 'Admin console unlocked',
        description: 'Phase 1 administrative preview ready.',
      });
      return { ok: true };
    },
    [appendLog, addToast]
  );

  const logoutAdmin = useCallback(() => {
    setState((prev) => ({
      ...prev,
      isAdminAuthenticated: false,
    }));
    addToast({
      type: 'info',
      title: 'Admin signed out',
    });
  }, [addToast]);

  const generateKeys = useCallback(
    (input: GenerateKeysInput) => {
      const count = Math.min(25, Math.max(1, input.count));
      const distributor = state.distributors.find((d) => d.id === input.distributorId);
      const nowIso = new Date().toISOString();
      const created: ProductKeyRecord[] = [];

      for (let i = 0; i < count; i++) {
        const keyStr =
          i === 0 && input.customKey && PRODUCT_KEY_REGEX.test(input.customKey.toUpperCase())
            ? input.customKey.toUpperCase()
            : generateDemoProductKey();

        const expiresAt = new Date(Date.now() + input.durationDays * 86_400_000).toISOString();
        created.push({
          id: `key-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
          key: keyStr,
          status: 'active',
          durationDays: input.durationDays,
          deviceLimit: input.deviceLimit,
          devicesUsed: 0,
          allowedServers: input.allowedServers.length > 0 ? input.allowedServers : ['singapore'],
          allowedFeatures: input.allowedFeatures.length > 0 ? input.allowedFeatures : ['only_aim_point'],
          distributorId: distributor?.id ?? 'dist-1',
          distributorName: distributor?.name ?? 'Direct Admin',
          activationRule: input.activationRule,
          createdAt: nowIso,
          activatedAt: input.activationRule === 'immediate' ? nowIso : null,
          expiresAt,
        });
      }

      setState((prev) => ({
        ...prev,
        keys: [...created, ...prev.keys],
        distributors: prev.distributors.map((d) =>
          d.id === input.distributorId
            ? {
                ...d,
                keysGenerated: d.keysGenerated + count,
                lastActivity: nowIso,
              }
            : d
        ),
        securityLogs: appendLog(prev.securityLogs, {
          event: `Generated ${count} product key${count > 1 ? 's' : ''}`,
          actor: 'Admin Console',
          target: count === 1 ? maskProductKey(created[0].key) : `${count} Keys Batch`,
          severity: 'info',
          region: 'Global',
        }),
      }));

      addToast({
        type: 'success',
        title: `Generated ${count} key${count > 1 ? 's' : ''}`,
        description: count === 1 ? created[0].key : 'Added to Key Management demonstration table.',
      });

      return created;
    },
    [state.distributors, appendLog, addToast]
  );

  const updateKeyStatus = useCallback(
    (keyId: string, status: KeyStatus) => {
      setState((prev) => {
        const target = prev.keys.find((k) => k.id === keyId);
        return {
          ...prev,
          keys: prev.keys.map((k) => (k.id === keyId ? { ...k, status } : k)),
          securityLogs: target
            ? appendLog(prev.securityLogs, {
                event: `Key status changed to ${status}`,
                actor: 'Admin Console',
                target: maskProductKey(target.key),
                severity: status === 'revoked' ? 'critical' : status === 'suspended' ? 'warning' : 'info',
                region: 'Global',
              })
            : prev.securityLogs,
        };
      });
      addToast({
        type: status === 'active' ? 'success' : 'warning',
        title: `Key marked as ${status}`,
      });
    },
    [appendLog, addToast]
  );

  const deleteKey = useCallback(
    (keyId: string) => {
      setState((prev) => {
        const target = prev.keys.find((k) => k.id === keyId);
        return {
          ...prev,
          keys: prev.keys.filter((k) => k.id !== keyId),
          securityLogs: target
            ? appendLog(prev.securityLogs, {
                event: 'Product key deleted',
                actor: 'Admin Console',
                target: maskProductKey(target.key),
                severity: 'warning',
                region: 'Global',
              })
            : prev.securityLogs,
        };
      });
      addToast({
        type: 'info',
        title: 'Key removed',
        description: 'Demonstration record deleted from local list.',
      });
    },
    [appendLog, addToast]
  );

  const updateSubscriptionUrl = useCallback(
    (slotId: string, url: string) => {
      const trimmed = url.trim();
      setState((prev) => ({
        ...prev,
        subscriptionUrls: prev.subscriptionUrls.map((slot) =>
          slot.id === slotId
            ? {
                ...slot,
                url: trimmed,
                updatedAt: trimmed ? new Date().toISOString() : null,
              }
            : slot
        ),
        securityLogs: appendLog(prev.securityLogs, {
          event: trimmed ? 'Updated subscription configuration field' : 'Cleared subscription configuration field',
          actor: 'Admin Console',
          target: slotId.replace('__', ' · '),
          severity: 'info',
          region: slotId.split('__')[0],
        }),
      }));
      addToast({
        type: trimmed ? 'success' : 'info',
        title: trimmed ? 'Configuration saved' : 'Configuration cleared',
      });
    },
    [appendLog, addToast]
  );

  const updateServer = useCallback(
    (serverId: ServerRegionId, patch: Partial<ServerRegion>) => {
      setState((prev) => ({
        ...prev,
        servers: prev.servers.map((s) => (s.id === serverId ? { ...s, ...patch } : s)),
      }));
      addToast({
        type: 'success',
        title: 'Server configuration updated',
      });
    },
    [addToast]
  );

  const updateFeature = useCallback(
    (featureId: FeatureId, patch: Partial<FeatureConfig>) => {
      setState((prev) => ({
        ...prev,
        features: prev.features.map((f) => (f.id === featureId ? { ...f, ...patch } : f)),
      }));
      addToast({
        type: 'success',
        title: 'Feature permission updated',
      });
    },
    [addToast]
  );

  const addDistributor = useCallback(
    (input: AddDistributorInput) => {
      const nowIso = new Date().toISOString();
      const created: Distributor = {
        id: `dist-${Date.now()}`,
        name: input.name.trim(),
        handle: input.handle.startsWith('@') ? input.handle.trim() : `@${input.handle.trim()}`,
        email: input.email.trim(),
        status: 'active',
        generationLimit: input.generationLimit,
        keysGenerated: 0,
        activeSubscriptions: 0,
        totalSalesUsd: 0,
        allowedServers: input.allowedServers,
        allowedFeatures: input.allowedFeatures,
        joinedAt: nowIso,
        lastActivity: nowIso,
      };

      setState((prev) => ({
        ...prev,
        distributors: [created, ...prev.distributors],
        securityLogs: appendLog(prev.securityLogs, {
          event: 'Distributor added',
          actor: 'Admin Console',
          target: created.name,
          severity: 'info',
          region: 'Global',
        }),
      }));
      addToast({
        type: 'success',
        title: 'Distributor added',
        description: `${created.name} is now active.`,
      });
    },
    [appendLog, addToast]
  );

  const toggleDistributorStatus = useCallback(
    (distributorId: string) => {
      setState((prev) => ({
        ...prev,
        distributors: prev.distributors.map((d) =>
          d.id === distributorId
            ? { ...d, status: d.status === 'active' ? 'suspended' : 'active' }
            : d
        ),
      }));
      addToast({
        type: 'info',
        title: 'Distributor status updated',
      });
    },
    [addToast]
  );

  const updateDistributor = useCallback(
    (distributorId: string, patch: Partial<Distributor>) => {
      setState((prev) => ({
        ...prev,
        distributors: prev.distributors.map((d) =>
          d.id === distributorId ? { ...d, ...patch } : d
        ),
      }));
      addToast({
        type: 'success',
        title: 'Distributor permissions saved',
      });
    },
    [addToast]
  );

  const deleteDistributor = useCallback(
    (distributorId: string) => {
      setState((prev) => ({
        ...prev,
        distributors: prev.distributors.filter((d) => d.id !== distributorId),
      }));
      addToast({
        type: 'info',
        title: 'Distributor removed',
      });
    },
    [addToast]
  );

  const updateDeviceStatus = useCallback(
    (deviceId: string, status: RegisteredDevice['status']) => {
      setState((prev) => ({
        ...prev,
        devices: prev.devices.map((d) => (d.id === deviceId ? { ...d, status } : d)),
        securityLogs: appendLog(prev.securityLogs, {
          event: `Device marked ${status}`,
          actor: 'Admin Console',
          target: deviceId,
          severity: status === 'blocked' ? 'critical' : 'info',
          region: 'Global',
        }),
      }));
      addToast({
        type: status === 'blocked' ? 'warning' : 'success',
        title: `Device ${status}`,
      });
    },
    [appendLog, addToast]
  );

  const unbindDevice = useCallback(
    (deviceId: string) => {
      setState((prev) => ({
        ...prev,
        devices: prev.devices.filter((d) => d.id !== deviceId),
      }));
      addToast({
        type: 'info',
        title: 'Device unbound',
        description: 'Slot freed in demonstration list.',
      });
    },
    [addToast]
  );

  const updateSettings = useCallback(
    (patch: Partial<WebsiteSettings>) => {
      setState((prev) => ({
        ...prev,
        settings: { ...prev.settings, ...patch },
      }));
      addToast({
        type: 'success',
        title: 'Settings saved',
      });
    },
    [addToast]
  );

  const removeAdminDevice = useCallback(
    (deviceId: string) => {
      setState((prev) => ({
        ...prev,
        adminDevices: prev.adminDevices.filter((d) => d.id !== deviceId),
      }));
      addToast({
        type: 'info',
        title: 'Admin device session revoked',
      });
    },
    [addToast]
  );

  const resetDemoData = useCallback(() => {
    const fresh: PersistedState = {
      keys: INITIAL_KEYS,
      servers: INITIAL_SERVERS,
      features: INITIAL_FEATURES,
      subscriptionUrls: INITIAL_SUBSCRIPTION_URLS,
      distributors: INITIAL_DISTRIBUTORS,
      devices: INITIAL_DEVICES,
      securityLogs: INITIAL_SECURITY_LOGS,
      adminDevices: INITIAL_ADMIN_DEVICES,
      settings: INITIAL_SETTINGS,
      userSession: null,
      isAdminAuthenticated: state.isAdminAuthenticated,
    };
    setState(fresh);
    addToast({
      type: 'info',
      title: 'Demo data restored',
      description: 'All demonstration lists reset to Phase 1 defaults.',
    });
  }, [state.isAdminAuthenticated, addToast]);

  return (
    <AppStateContext.Provider
      value={{
        ...state,
        toasts,
        addToast,
        dismissToast,
        loginUser,
        logoutUser,
        selectUserServer,
        toggleUserFeature,
        loginAdmin,
        logoutAdmin,
        generateKeys,
        updateKeyStatus,
        deleteKey,
        updateSubscriptionUrl,
        updateServer,
        updateFeature,
        addDistributor,
        toggleDistributorStatus,
        updateDistributor,
        deleteDistributor,
        updateDeviceStatus,
        unbindDevice,
        updateSettings,
        removeAdminDevice,
        resetDemoData,
      }}
    >
      {children}
    </AppStateContext.Provider>
  );
};

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}
