import React, { useCallback, useEffect, useState } from 'react';
import { Download, Lock, RefreshCw, Search } from 'lucide-react';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { downloadCsv, formatDateTime } from '../../utils/formatters';

interface SecurityLogRow {
  id: string;
  event_type: string;
  timestamp: string;
  actor_type: string;
  actor_id: string | null;
  actor_label: string;
  resource_type: string | null;
  resource_id: string | null;
  result: 'success' | 'denied' | 'error';
  details: string;
  ip_hash: string;
}

const RESULT_BADGE: Record<SecurityLogRow['result'], string> = {
  success: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/25',
  denied: 'bg-amber-500/10 text-amber-300 border-amber-500/25',
  error: 'bg-rose-500/10 text-rose-300 border-rose-500/25',
};

export const SecurityLogsPage: React.FC = () => {
  const { addToast } = useToast();

  const [logs, setLogs] = useState<SecurityLogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [resultFilter, setResultFilter] = useState('all');
  const [search, setSearch] = useState('');

  const loadLogs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (resultFilter !== 'all') params.set('result', resultFilter);
      if (search.trim()) params.set('search', search.trim());
      const res = await apiRequest<{ logs: SecurityLogRow[] }>(
        `/api/admin/logs?${params.toString()}`,
        { scope: 'admin' }
      );
      setLogs(res.logs);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to load security logs',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [resultFilter, search, addToast]);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const handleExport = () => {
    if (logs.length === 0) return;
    downloadCsv(
      'primewirepro-security-logs.csv',
      logs.map((l) => ({
        timestamp: l.timestamp,
        event_type: l.event_type,
        result: l.result,
        actor_type: l.actor_type,
        actor_label: l.actor_label,
        resource_type: l.resource_type ?? '',
        resource_id: l.resource_id ?? '',
        details: l.details,
        ip_hash: l.ip_hash,
      }))
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Security Logs</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Immutable audit trail of authentications, bindings, admin actions, and denied requests.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={logs.length === 0}
            onClick={handleExport}
            className="min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-45 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            type="button"
            onClick={loadLogs}
            className="min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <div className="rounded-xl bg-[#101015] border border-zinc-800/80 px-4 py-3 flex items-center gap-2.5 text-xs text-zinc-400">
        <Lock className="w-4 h-4 text-purple-400 shrink-0" />
        <span>Append-only audit store: records cannot be edited or deleted from the dashboard.</span>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search event type, actor, or details..."
            className="w-full h-11 pl-10 pr-4 rounded-xl bg-[#101015] border border-zinc-800 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-purple-500"
          />
        </div>

        <select
          aria-label="Filter log result"
          value={resultFilter}
          onChange={(e) => setResultFilter(e.target.value)}
          className="h-11 px-3.5 rounded-xl bg-[#101015] border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-purple-500"
        >
          <option value="all">All Results</option>
          <option value="success">Success</option>
          <option value="denied">Denied</option>
          <option value="error">Error</option>
        </select>
      </div>

      {loading && logs.length === 0 ? (
        <p className="text-sm text-zinc-400">Loading security audit trail...</p>
      ) : logs.length === 0 ? (
        <div className="rounded-2xl bg-[#101015] border border-zinc-800 p-8 text-center text-sm text-zinc-500">
          No matching security events found.
        </div>
      ) : (
        <>
          <div className="hidden lg:block rounded-2xl bg-[#101015] border border-zinc-800/90 overflow-hidden">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4 font-medium">Timestamp</th>
                  <th className="py-3 px-4 font-medium">Event</th>
                  <th className="py-3 px-4 font-medium">Actor</th>
                  <th className="py-3 px-4 font-medium">Result</th>
                  <th className="py-3 px-4 font-medium">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/70">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 font-mono text-zinc-400 whitespace-nowrap tabular-nums">
                      {formatDateTime(log.timestamp)}
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-zinc-100 whitespace-nowrap">
                      {log.event_type}
                    </td>
                    <td className="py-3 px-4 text-zinc-300">
                      <span className="font-medium">{log.actor_label}</span>{' '}
                      <span className="text-zinc-500">({log.actor_type})</span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded border text-[11px] font-medium capitalize ${
                          RESULT_BADGE[log.result] ?? RESULT_BADGE.error
                        }`}
                      >
                        {log.result}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-zinc-400 max-w-md truncate" title={log.details}>
                      {log.details || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="lg:hidden space-y-3">
            {logs.map((log) => (
              <div
                key={log.id}
                className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono font-semibold text-white truncate">
                    {log.event_type}
                  </span>
                  <span
                    className={`inline-flex px-2 py-0.5 rounded border text-[11px] font-medium capitalize shrink-0 ${
                      RESULT_BADGE[log.result] ?? RESULT_BADGE.error
                    }`}
                  >
                    {log.result}
                  </span>
                </div>
                <p className="text-zinc-300">
                  {log.actor_label} <span className="text-zinc-500">({log.actor_type})</span>
                </p>
                {log.details && <p className="text-zinc-400 break-words">{log.details}</p>}
                <p className="font-mono text-[11px] text-zinc-500 tabular-nums">
                  {formatDateTime(log.timestamp)}
                </p>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};
