import React from 'react';

interface ToggleSwitchProps {
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
  label: string;
}

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({
  checked,
  onChange,
  disabled = false,
  label,
}) => {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={onChange}
      className={`relative inline-flex items-center shrink-0 min-w-[52px] min-h-[44px] justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 rounded-xl ${
        disabled ? 'opacity-45 cursor-not-allowed' : 'cursor-pointer'
      }`}
    >
      <span
        className={`w-12 h-7 rounded-full transition-colors duration-200 flex items-center px-1 border ${
          checked
            ? 'bg-purple-600 border-purple-400/50 shadow-[0_0_16px_rgba(168,85,247,0.45)]'
            : 'bg-zinc-800 border-white/10'
        }`}
      >
        <span
          className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-200 ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </span>
    </button>
  );
};
