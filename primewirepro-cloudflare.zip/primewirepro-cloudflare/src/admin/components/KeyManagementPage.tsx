import React, { useCallback, useEffect, useState } from 'react';
import {
  Ban,
  CheckCircle2,
  Copy,
  Download,
  History,
  PauseCircle,
  Plus,
  Search,
  Trash2,
  Unlink,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { FeatureId, ServerId } from '../../shared/types';
import {
  downloadCsv,
  formatDateShort,
  formatDateTime,
  formatProductKeyInput,
} from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface KeyRow {
  id: string;
  key_code: string;
  status: 'active' | 'suspended' | 'revoked' | 'expired';
  duration_seconds: number;
  custom_expires_at: string | null;
  bound_device_id: string | null;
  device_label: string | null;
  device_platform: string | null;
  created_at: string;
  activated_at: string | null;
  expires_at: string | null;
  notes: string;
}

interface HistoryRow {
  id: string;
  server_id: string;
  feature_id: string;
  status: string;
  reason: string;
  created_at: string;
}

const ALL_SERVERS: { id: ServerId; label: string }[] = [
  { id: 'brazil', label: 'Brazil' },
  { id: 'india', label: 'India' },
  { id: 'singapore', label: 'Singapore' },
  { id: 'europe', label: 'Europe' },
  { id: 'bangladesh', label: 'Bangladesh' },
];

const ALL_FEATURES: { id: FeatureId; label: string }[] = [
  { id: 'aim_point', label: 'AIM POINT' },
  { id: 'aim_point_moco_mark', label: 'AIM POINT AND MOCO MARK' },
];

export const KeyManagementPage: React.FC = () => {
  const { can } = useAdminAuth();
  const { addToast } = useToast();

  const [keys, setKeys] = useState<KeyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const [createOpen, setCreateOpen] = useState(false);
  const [count, setCount] = useState(1);
  const [customKey, setCustomKey] = useState('');
  const [durationSeconds, setDurationSeconds] = useState(30 * 86400);
  const [customExpiresAt, setCustomExpiresAt] = useState('');
  const [allowedServers, setAllowedServers] = useState<ServerId[]>(
    ALL_SERVERS.map((s) => s.id)
  );
  const [allowedFeatures, setAllowedFeatures] = useState<FeatureId[]>(
    ALL_FEATURES.map((f) => f.id)
  );
  const [notes, setNotes] = useState('');

  const [historyKey, setHistoryKey] = useState<KeyRow | null>(null);
  const [historyRows, setHistoryRows] = useState<HistoryRow[]>([]);

  const loadKeys = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (search.trim()) params.set('search', search.trim());
      const res = await apiRequest<{ keys: KeyRow[] }>(
        `/api/admin/keys?${params.toString()}`,
        { scope: 'admin' }
      );
      setKeys(res.keys);
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to load keys',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [statusFilter, search, addToast]);

  useEffect(() => {
    loadKeys();
  }, [loadKeys]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await apiRequest<{ ok: boolean; created: { key_code: string }[] }>(
        '/api/admin/keys',
        {
          method: 'POST',
          scope: 'admin',
          body: {
            count,
            customKey: count === 1 && customKey ? customKey : undefined,
            durationSeconds,
            customExpiresAt: customExpiresAt ? new Date(customExpiresAt).toISOString() : null,
            allowedServers,
            allowedFeatures,
            notes,
          },
        }
      );
      addToast({
        type: 'success',
        title: `Generated ${res.created.length} product key(s)`,
        description: res.created.length === 1 ? res.created[0].key_code : undefined,
      });
      setCreateOpen(false);
      setCustomKey('');
      setCustomExpiresAt('');
      setNotes('');
      await loadKeys();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Generation failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const setKeyStatus = async (id: string, status: 'active' | 'suspended' | 'revoked') => {
    try {
      await apiRequest(`/api/admin/keys/${id}/status`, {
        method: 'POST',
        scope: 'admin',
        body: { status },
      });
      addToast({ type: 'success', title: `Key marked ${status}` });
      await loadKeys();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Action failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const unbindDevice = async (id: string) => {
    try {
      await apiRequest(`/api/admin/keys/${id}/unbind`, {
        method: 'POST',
        scope: 'admin',
      });
      addToast({
        type: 'success',
        title: 'Device unbound',
        description: 'Key is now available for activation on a new device.',
      });
      await loadKeys();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Unbind failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const deleteKey = async (id: string) => {
    try {
      await apiRequest(`/api/admin/keys/${id}`, {
        method: 'DELETE',
        scope: 'admin',
      });
      addToast({ type: 'info', title: 'Product key deleted' });
      await loadKeys();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Delete failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const openHistory = async (row: KeyRow) => {
    setHistoryKey(row);
    try {
      const res = await apiRequest<{ history: HistoryRow[] }>(
        `/api/admin/keys/${row.id}/history`,
        { scope: 'admin' }
      );
      setHistoryRows(res.history);
    } catch {
      setHistoryRows([]);
    }
  };

  const copyKey = async (k: string) => {
    try {
      await navigator.clipboard.writeText(k);
      addToast({ type: 'success', title: 'Copied key', description: k });
    } catch {
      addToast({ type: 'info', title: k });
    }
  };

  const formatDurationLabel = (secs: number) => {
    if (secs < 86400) return `${Math.round(secs / 3600)}h`;
    return `${Math.round(secs / 86400)}d`;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Key Management</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Individual keys enforce permanent 1-device binding until manually unbound by an admin.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={keys.length === 0}
            onClick={() =>
              downloadCsv(
                'primewirepro-keys.csv',
                keys.map((k) => ({
                  key: k.key_code,
                  status: k.status,
                  duration: formatDurationLabel(k.duration_seconds),
                  boundDevice: k.bound_device_id ?? 'unbound',
                  createdAt: k.created_at,
                  activatedAt: k.activated_at ?? '',
                  expiresAt: k.expires_at ?? '',
                }))
              )
            }
            className="min-h-[42px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-40 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
          >
            <Download className="w-4 h-4 text-purple-400" />
            <span>Export CSV</span>
          </button>

          {can('keys.manage') && (
            <button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="min-h-[42px] px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>Generate Keys</span>
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1 flex items-center">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search PMWR key or notes..."
            className="w-full min-h-[42px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {(['all', 'active', 'suspended', 'revoked', 'expired'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`min-h-[40px] px-3 rounded-xl text-xs font-medium capitalize border transition-colors ${
                statusFilter === st
                  ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                  : 'bg-[#07070A] border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Key Table / Mobile Cards */}
      {loading ? (
        <p className="text-sm text-zinc-400">Loading keys...</p>
      ) : keys.length === 0 ? (
        <div className="rounded-2xl bg-[#101015] border border-zinc-800 p-10 text-center">
          <p className="text-sm font-medium text-zinc-300">No product keys found</p>
          <p className="text-xs text-zinc-500 mt-1">
            Generate your first individual product key to begin.
          </p>
        </div>
      ) : (
        <>
          <div className="hidden lg:block rounded-2xl bg-[#101015] border border-zinc-800/90 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 bg-[#0B0B10]">
                    <th className="py-3.5 px-4 font-medium">Product Key</th>
                    <th className="py-3.5 px-4 font-medium">Status</th>
                    <th className="py-3.5 px-4 font-medium">Duration</th>
                    <th className="py-3.5 px-4 font-medium">Linked Device</th>
                    <th className="py-3.5 px-4 font-medium">Created / Activated</th>
                    <th className="py-3.5 px-4 font-medium">Expires</th>
                    <th className="py-3.5 px-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/70">
                  {keys.map((k) => (
                    <tr key={k.id} className="hover:bg-white/[0.02]">
                      <td className="py-3.5 px-4 font-mono text-zinc-100 whitespace-nowrap">
                        {k.key_code}
                      </td>
                      <td
                        className={`py-3.5 px-4 font-semibold capitalize ${
                          k.status === 'active'
                            ? 'text-emerald-400'
                            : k.status === 'suspended'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {k.status}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-300 tabular-nums">
                        {formatDurationLabel(k.duration_seconds)}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-300">
                        {k.bound_device_id ? (
                          <span>
                            {k.device_label ?? 'Registered'} ({k.device_platform ?? 'Device'})
                          </span>
                        ) : (
                          <span className="text-zinc-500">Unbound</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-400 tabular-nums">
                        <div>{formatDateShort(k.created_at)}</div>
                        <div className="text-[11px] text-zinc-500">
                          Act: {k.activated_at ? formatDateShort(k.activated_at) : 'Pending'}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-zinc-300 tabular-nums whitespace-nowrap">
                        {k.expires_at ? formatDateTime(k.expires_at) : 'On first activation'}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => copyKey(k.key_code)}
                            title="Copy key"
                            className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openHistory(k)}
                            title="Usage history"
                            className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-white/10 text-zinc-400 hover:text-purple-300 flex items-center justify-center"
                          >
                            <History className="w-3.5 h-3.5" />
                          </button>
                          {can('devices.unbind') && k.bound_device_id && (
                            <button
                              type="button"
                              onClick={() => unbindDevice(k.id)}
                              title="Manually unbind device"
                              className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-purple-500/15 text-purple-300 flex items-center justify-center"
                            >
                              <Unlink className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {can('keys.manage') && (
                            <>
                              {k.status !== 'active' ? (
                                <button
                                  type="button"
                                  onClick={() => setKeyStatus(k.id, 'active')}
                                  title="Reactivate key"
                                  className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-emerald-500/15 text-zinc-400 hover:text-emerald-400 flex items-center justify-center"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setKeyStatus(k.id, 'suspended')}
                                  title="Suspend key"
                                  className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-amber-500/15 text-zinc-400 hover:text-amber-400 flex items-center justify-center"
                                >
                                  <PauseCircle className="w-3.5 h-3.5" />
                                </button>
                              )}
                              {k.status !== 'revoked' && (
                                <button
                                  type="button"
                                  onClick={() => setKeyStatus(k.id, 'revoked')}
                                  title="Revoke key"
                                  className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-rose-500/15 text-zinc-400 hover:text-rose-400 flex items-center justify-center"
                                >
                                  <Ban className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => deleteKey(k.id)}
                                title="Delete key"
                                className="min-w-[32px] min-h-[32px] rounded-lg hover:bg-rose-500/15 text-zinc-500 hover:text-rose-400 flex items-center justify-center"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="lg:hidden space-y-3">
            {keys.map((k) => (
              <div
                key={k.id}
                className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 space-y-3 text-xs"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-mono text-sm text-white truncate">{k.key_code}</p>
                    <p className="text-zinc-400 mt-0.5">
                      {formatDurationLabel(k.duration_seconds)} ·{' '}
                      {k.bound_device_id ? `Bound (${k.device_platform ?? 'Device'})` : 'Unbound'}
                    </p>
                  </div>
                  <span className="capitalize font-semibold text-zinc-200">{k.status}</span>
                </div>
                <div className="flex flex-wrap gap-2 pt-2 border-t border-zinc-800/70">
                  <button
                    type="button"
                    onClick={() => copyKey(k.key_code)}
                    className="min-h-[36px] px-3 rounded-lg bg-white/5 text-zinc-200"
                  >
                    Copy
                  </button>
                  {can('devices.unbind') && k.bound_device_id && (
                    <button
                      type="button"
                      onClick={() => unbindDevice(k.id)}
                      className="min-h-[36px] px-3 rounded-lg bg-purple-500/15 text-purple-200"
                    >
                      Unbind Device
                    </button>
                  )}
                  {can('keys.manage') && (
                    <button
                      type="button"
                      onClick={() =>
                        setKeyStatus(k.id, k.status === 'active' ? 'suspended' : 'active')
                      }
                      className="min-h-[36px] px-3 rounded-lg bg-amber-500/10 text-amber-300"
                    >
                      {k.status === 'active' ? 'Suspend' : 'Reactivate'}
                    </button>
                  )}
                  {can('keys.manage') && (
                    <button
                      type="button"
                      onClick={() => deleteKey(k.id)}
                      className="min-h-[36px] px-3 rounded-lg bg-rose-500/10 text-rose-300"
                    >
                      Delete
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Generate Keys Modal */}
      <Modal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        title="Generate Product Keys"
        subtitle="Creates permanent 1-device bound product keys in Cloudflare D1"
      >
        <form onSubmit={handleGenerate} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="k-count" className="block text-xs font-medium text-zinc-300 mb-1">
                Quantity (1–25)
              </label>
              <input
                id="k-count"
                type="number"
                min={1}
                max={25}
                value={count}
                onChange={(e) => setCount(Math.min(25, Math.max(1, Number(e.target.value) || 1)))}
                className="w-full min-h-[42px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white"
              />
            </div>
            <div>
              <label htmlFor="k-dur" className="block text-xs font-medium text-zinc-300 mb-1">
                Duration Preset
              </label>
              <select
                id="k-dur"
                value={durationSeconds}
                onChange={(e) => setDurationSeconds(Number(e.target.value))}
                className="w-full min-h-[42px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
              >
                <option value={3600}>1 Hour</option>
                <option value={86400}>24 Hours</option>
                <option value={7 * 86400}>7 Days</option>
                <option value={30 * 86400}>30 Days</option>
                <option value={90 * 86400}>90 Days</option>
                <option value={365 * 86400}>365 Days</option>
              </select>
            </div>
          </div>

          {count === 1 && (
            <div>
              <label htmlFor="k-custom" className="block text-xs font-medium text-zinc-300 mb-1">
                Custom Key (Optional — leave blank to auto-generate)
              </label>
              <input
                id="k-custom"
                type="text"
                value={customKey}
                onChange={(e) => setCustomKey(formatProductKeyInput(e.target.value))}
                placeholder="PMWR-XXXX-XXXX-XXXX"
                maxLength={19}
                className="w-full min-h-[42px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white"
              />
            </div>
          )}

          <div>
            <label htmlFor="k-exp" className="block text-xs font-medium text-zinc-300 mb-1">
              Custom Expiration Date/Time (Optional)
            </label>
            <input
              id="k-exp"
              type="datetime-local"
              value={customExpiresAt}
              onChange={(e) => setCustomExpiresAt(e.target.value)}
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white"
            />
          </div>

          <div>
            <p className="text-xs font-medium text-zinc-300 mb-1.5">Allowed Servers</p>
            <div className="flex flex-wrap gap-2">
              {ALL_SERVERS.map((s) => {
                const on = allowedServers.includes(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() =>
                      setAllowedServers((prev) =>
                        on ? (prev.length > 1 ? prev.filter((x) => x !== s.id) : prev) : [...prev, s.id]
                      )
                    }
                    className={`min-h-[36px] px-3 rounded-lg text-xs border ${
                      on
                        ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                        : 'bg-[#07070A] border-zinc-800 text-zinc-500'
                    }`}
                  >
                    {s.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <p className="text-xs font-medium text-zinc-300 mb-1.5">Allowed Features</p>
            <div className="flex flex-wrap gap-2">
              {ALL_FEATURES.map((f) => {
                const on = allowedFeatures.includes(f.id);
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() =>
                      setAllowedFeatures((prev) =>
                        on ? (prev.length > 1 ? prev.filter((x) => x !== f.id) : prev) : [...prev, f.id]
                      )
                    }
                    className={`min-h-[36px] px-3 rounded-lg text-xs border ${
                      on
                        ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                        : 'bg-[#07070A] border-zinc-800 text-zinc-500'
                    }`}
                  >
                    {f.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="min-h-[42px] px-4 rounded-xl bg-white/5 text-xs font-medium text-zinc-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[42px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white"
            >
              Generate
            </button>
          </div>
        </form>
      </Modal>

      {/* Usage History Modal */}
      <Modal
        open={!!historyKey}
        onClose={() => setHistoryKey(null)}
        title={`Usage History · ${historyKey?.key_code ?? ''}`}
        subtitle="Subscription resolution and import attempts"
      >
        {historyRows.length === 0 ? (
          <p className="text-xs text-zinc-400 py-4 text-center">
            No subscription access records logged for this key yet.
          </p>
        ) : (
          <div className="space-y-2 max-h-72 overflow-y-auto text-xs">
            {historyRows.map((h) => (
              <div
                key={h.id}
                className="rounded-xl bg-[#07070A] border border-zinc-800 px-3.5 py-2.5 flex items-center justify-between gap-3"
              >
                <div>
                  <p className="text-zinc-200 font-medium">
                    {h.server_id.toUpperCase()} · {h.feature_id.toUpperCase()}
                  </p>
                  <p className="text-zinc-500 mt-0.5">{h.reason}</p>
                </div>
                <div className="text-right shrink-0">
                  <span className="capitalize text-purple-300">{h.status}</span>
                  <p className="text-[11px] text-zinc-500 tabular-nums">
                    {formatDateTime(h.created_at)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
};
