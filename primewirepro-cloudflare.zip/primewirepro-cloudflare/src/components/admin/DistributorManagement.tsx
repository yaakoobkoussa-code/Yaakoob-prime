import React, { useState } from 'react';
import {
  Check,
  DollarSign,
  KeyRound,
  Plus,
  Shield,
  Trash2,
  UserCheck,
  UserX,
} from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { Distributor, FeatureId, ServerRegionId } from '../../types';
import { formatDateTime } from '../../utils/formatters';
import { Modal } from '../common/Modal';

export const DistributorManagement: React.FC = () => {
  const {
    distributors,
    servers,
    features,
    keys,
    addDistributor,
    toggleDistributorStatus,
    updateDistributor,
    deleteDistributor,
  } = useAppState();

  const [addOpen, setAddOpen] = useState(false);
  const [editingDist, setEditingDist] = useState<Distributor | null>(null);
  const [activityDist, setActivityDist] = useState<Distributor | null>(null);

  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [email, setEmail] = useState('');
  const [limit, setLimit] = useState(100);
  const [selectedServers, setSelectedServers] = useState<ServerRegionId[]>([
    'brazil',
    'india',
    'singapore',
    'europe',
    'bangladesh',
  ]);
  const [selectedFeatures, setSelectedFeatures] = useState<FeatureId[]>([
    'only_aim_point',
    'aim_point_moco_mark',
  ]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !handle.trim()) return;
    addDistributor({
      name,
      handle,
      email: email.trim() || 'partner@demo.example',
      generationLimit: limit,
      allowedServers: selectedServers,
      allowedFeatures: selectedFeatures,
    });
    setName('');
    setHandle('');
    setEmail('');
    setLimit(100);
    setAddOpen(false);
  };

  const handleSavePermissions = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDist) return;
    updateDistributor(editingDist.id, {
      generationLimit: editingDist.generationLimit,
      allowedServers: editingDist.allowedServers,
      allowedFeatures: editingDist.allowedFeatures,
    });
    setEditingDist(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Distributor Management</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Manage reseller accounts, generation quotas, permissions, subscriptions, and sales.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setAddOpen(true)}
          className="self-start sm:self-auto min-h-[44px] px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white inline-flex items-center gap-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Distributor</span>
        </button>
      </div>

      {/* Responsive Distributor Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {distributors.map((dist) => {
          const quotaPct = Math.min(
            100,
            Math.round((dist.keysGenerated / Math.max(1, dist.generationLimit)) * 100)
          );
          const distKeysCount = keys.filter((k) => k.distributorId === dist.id).length;

          return (
            <div
              key={dist.id}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h2 className="font-display text-base font-semibold text-white truncate">
                      {dist.name}
                    </h2>
                    <span
                      className={`text-xs font-medium capitalize ${
                        dist.status === 'active' ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      · {dist.status}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    {dist.handle} · {dist.email}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => deleteDistributor(dist.id)}
                  aria-label={`Remove ${dist.name}`}
                  className="min-w-[36px] min-h-[36px] rounded-lg hover:bg-rose-500/15 text-zinc-500 hover:text-rose-400 flex items-center justify-center shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-3 rounded-xl bg-[#07070A] border border-zinc-800/80 p-3 text-xs">
                <div>
                  <span className="text-zinc-500 flex items-center gap-1">
                    <KeyRound className="w-3 h-3" />
                    Keys
                  </span>
                  <p className="mt-1 font-mono font-semibold text-white tabular-nums">
                    {dist.keysGenerated} / {dist.generationLimit}
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500 flex items-center gap-1">
                    <UserCheck className="w-3 h-3" />
                    Active Subs
                  </span>
                  <p className="mt-1 font-mono font-semibold text-emerald-400 tabular-nums">
                    {dist.activeSubscriptions}
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500 flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    Sales (Demo)
                  </span>
                  <p className="mt-1 font-mono font-semibold text-purple-300 tabular-nums">
                    ${dist.totalSalesUsd.toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Quota Bar */}
              <div>
                <div className="flex items-center justify-between text-[11px] text-zinc-400 mb-1">
                  <span>Generation Quota Usage</span>
                  <span className="tabular-nums">{quotaPct}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-zinc-900 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-purple-500"
                    style={{ width: `${quotaPct}%` }}
                  />
                </div>
              </div>

              {/* Action Row */}
              <div className="pt-2 border-t border-zinc-800/70 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => toggleDistributorStatus(dist.id)}
                  className={`min-h-[38px] px-3 rounded-lg text-xs font-medium inline-flex items-center gap-1.5 transition-colors ${
                    dist.status === 'active'
                      ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300'
                      : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300'
                  }`}
                >
                  {dist.status === 'active' ? (
                    <>
                      <UserX className="w-3.5 h-3.5" />
                      <span>Suspend</span>
                    </>
                  ) : (
                    <>
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Activate</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setEditingDist({ ...dist })}
                  className="min-h-[38px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-200 inline-flex items-center gap-1.5 transition-colors"
                >
                  <Shield className="w-3.5 h-3.5 text-purple-400" />
                  <span>Permissions & Limit</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActivityDist(dist)}
                  className="min-h-[38px] px-3 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-300 ml-auto transition-colors"
                >
                  Keys ({distKeysCount}) & Activity
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Distributor Modal */}
      <Modal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        title="Add Distributor"
        subtitle="Create a demonstration reseller account"
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label htmlFor="dist-name" className="block text-xs font-medium text-zinc-300 mb-1">
              Organization Name
            </label>
            <input
              id="dist-name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Nova Gaming Supply"
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="dist-handle" className="block text-xs font-medium text-zinc-300 mb-1">
                Handle
              </label>
              <input
                id="dist-handle"
                required
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                placeholder="@novasupply"
                className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
              />
            </div>
            <div>
              <label htmlFor="dist-limit" className="block text-xs font-medium text-zinc-300 mb-1">
                Generation Limit
              </label>
              <input
                id="dist-limit"
                type="number"
                min={10}
                max={5000}
                value={limit}
                onChange={(e) => setLimit(Number(e.target.value) || 50)}
                className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>
          <div>
            <label htmlFor="dist-email" className="block text-xs font-medium text-zinc-300 mb-1">
              Contact Email
            </label>
            <input
              id="dist-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="partner@example.com"
              className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setAddOpen(false)}
              className="min-h-[44px] px-4 rounded-xl bg-white/5 text-xs font-medium text-zinc-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white"
            >
              Create Distributor
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Permissions & Limits Modal */}
      <Modal
        open={!!editingDist}
        onClose={() => setEditingDist(null)}
        title={`Edit ${editingDist?.name ?? ''}`}
        subtitle="Assign allowed servers, features, and key generation limits"
      >
        {editingDist && (
          <form onSubmit={handleSavePermissions} className="space-y-4">
            <div>
              <label
                htmlFor="edit-limit"
                className="block text-xs font-medium text-zinc-300 mb-1.5"
              >
                Key Generation Limit
              </label>
              <input
                id="edit-limit"
                type="number"
                min={1}
                max={10000}
                value={editingDist.generationLimit}
                onChange={(e) =>
                  setEditingDist({
                    ...editingDist,
                    generationLimit: Number(e.target.value) || 1,
                  })
                }
                className="w-full min-h-[44px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm font-mono text-white"
              />
            </div>

            <div>
              <p className="text-xs font-medium text-zinc-300 mb-2">Allowed Servers</p>
              <div className="grid grid-cols-2 gap-2">
                {servers.map((srv) => {
                  const has = editingDist.allowedServers.includes(srv.id);
                  return (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() =>
                        setEditingDist({
                          ...editingDist,
                          allowedServers: has
                            ? editingDist.allowedServers.filter((id) => id !== srv.id)
                            : [...editingDist.allowedServers, srv.id],
                        })
                      }
                      className={`min-h-[40px] px-3 rounded-xl border text-xs flex items-center justify-between ${
                        has
                          ? 'bg-purple-600/20 border-purple-500 text-white'
                          : 'bg-[#07070A] border-zinc-800 text-zinc-500'
                      }`}
                    >
                      <span>
                        {srv.flag} {srv.name}
                      </span>
                      {has && <Check className="w-3.5 h-3.5 text-purple-400" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <p className="text-xs font-medium text-zinc-300 mb-2">Allowed Features</p>
              <div className="space-y-2">
                {features.map((feat) => {
                  const has = editingDist.allowedFeatures.includes(feat.id);
                  return (
                    <button
                      key={feat.id}
                      type="button"
                      onClick={() =>
                        setEditingDist({
                          ...editingDist,
                          allowedFeatures: has
                            ? editingDist.allowedFeatures.filter((id) => id !== feat.id)
                            : [...editingDist.allowedFeatures, feat.id],
                        })
                      }
                      className={`w-full min-h-[40px] px-3 rounded-xl border text-xs flex items-center justify-between ${
                        has
                          ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                          : 'bg-[#07070A] border-zinc-800 text-zinc-500'
                      }`}
                    >
                      <span>{feat.title}</span>
                      {has && <Check className="w-3.5 h-3.5 text-purple-400" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingDist(null)}
                className="min-h-[44px] px-4 rounded-xl bg-white/5 text-xs font-medium text-zinc-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[44px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-semibold text-white"
              >
                Save Permissions
              </button>
            </div>
          </form>
        )}
      </Modal>

      {/* View Keys & Activity Modal */}
      <Modal
        open={!!activityDist}
        onClose={() => setActivityDist(null)}
        title={activityDist?.name ?? 'Distributor Activity'}
        subtitle={`Last activity: ${formatDateTime(activityDist?.lastActivity ?? null)}`}
      >
        {activityDist && (
          <div className="space-y-3">
            <p className="text-xs text-zinc-400">
              Demonstration keys assigned to {activityDist.handle}:
            </p>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {keys.filter((k) => k.distributorId === activityDist.id).length === 0 ? (
                <p className="text-xs text-zinc-500 py-4 text-center">
                  No keys currently listed for this distributor.
                </p>
              ) : (
                keys
                  .filter((k) => k.distributorId === activityDist.id)
                  .map((k) => (
                    <div
                      key={k.id}
                      className="rounded-xl bg-[#07070A] border border-zinc-800 px-3.5 py-2.5 flex items-center justify-between text-xs"
                    >
                      <span className="font-mono text-zinc-200">{k.key}</span>
                      <span className="capitalize text-zinc-400">{k.status}</span>
                    </div>
                  ))
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
