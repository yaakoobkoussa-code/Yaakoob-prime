export type ServerRegionId = 'brazil' | 'india' | 'singapore' | 'europe' | 'bangladesh';

export type FeatureId = 'only_aim_point' | 'aim_point_moco_mark';

export type KeyStatus = 'active' | 'expired' | 'revoked' | 'suspended';

export type ActivationRule = 'on_first_login' | 'immediate';

export type UserTab = 'home' | 'features' | 'account';

export type AdminSection =
  | 'dashboard'
  | 'key-generator'
  | 'keys'
  | 'distributors'
  | 'subscription-urls'
  | 'servers'
  | 'features'
  | 'device-protection'
  | 'security-logs'
  | 'settings';

export interface ServerRegion {
  id: ServerRegionId;
  name: string;
  flag: string;
  code: string;
  status: 'operational' | 'high_load' | 'maintenance';
  simulatedLatencyMs: number;
  activeUsersDemo: number;
  capacityLimit: number;
  priority: number;
  routingNote: string;
}

export interface FeatureConfig {
  id: FeatureId;
  title: 'ONLY AIM POINT' | 'AIM POINT AND MOCO MARK';
  description: string;
  globallyEnabled: boolean;
  defaultAuthorized: boolean;
  allowedServers: ServerRegionId[];
}

export interface SubscriptionUrlSlot {
  id: string;
  serverId: ServerRegionId;
  serverName: string;
  serverFlag: string;
  featureId: FeatureId;
  featureTitle: 'ONLY AIM POINT' | 'AIM POINT AND MOCO MARK';
  url: string;
  updatedAt: string | null;
}

export interface ProductKeyRecord {
  id: string;
  key: string; // PMWR-XXXX-XXXX-XXXX
  status: KeyStatus;
  durationDays: number;
  deviceLimit: number;
  devicesUsed: number;
  allowedServers: ServerRegionId[];
  allowedFeatures: FeatureId[];
  distributorId: string;
  distributorName: string;
  activationRule: ActivationRule;
  createdAt: string;
  activatedAt: string | null;
  expiresAt: string;
  lastUsedDevice?: string;
}

export interface Distributor {
  id: string;
  name: string;
  handle: string;
  email: string;
  status: 'active' | 'suspended';
  generationLimit: number;
  keysGenerated: number;
  activeSubscriptions: number;
  totalSalesUsd: number;
  allowedServers: ServerRegionId[];
  allowedFeatures: FeatureId[];
  joinedAt: string;
  lastActivity: string;
}

export interface RegisteredDevice {
  id: string;
  deviceName: string;
  platform: 'Android' | 'iOS' | 'iPadOS' | 'Windows' | 'macOS';
  hardwareHash: string;
  boundKey: string;
  regionId: ServerRegionId;
  status: 'trusted' | 'flagged' | 'blocked';
  lastActiveAt: string;
  ipMasked: string;
}

export interface SecurityLogEntry {
  id: string;
  timestamp: string;
  event: string;
  actor: string;
  target: string;
  severity: 'info' | 'warning' | 'critical';
  region: string;
}

export interface AdminDevice {
  id: string;
  label: string;
  browser: string;
  lastSeen: string;
  current: boolean;
}

export interface WebsiteSettings {
  websiteTitle: string;
  maintenanceMode: boolean;
  systemMessage: string;
  defaultServerId: ServerRegionId;
  twoFactorEnabled: boolean;
  sessionTimeoutMinutes: number;
  singleAdminSession: boolean;
  autoBlockMultiDevice: boolean;
  strictHwidBinding: boolean;
}

export interface UserSession {
  keyRecordId: string;
  productKey: string;
  rememberDevice: boolean;
  selectedServerId: ServerRegionId;
  activeFeatureId: FeatureId | null;
  deviceLabel: string;
  platformName: string;
  signedInAt: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}
