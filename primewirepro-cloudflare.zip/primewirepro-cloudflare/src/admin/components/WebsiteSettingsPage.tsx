import React, { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, RefreshCw, Save, Settings } from 'lucide-react';
import { ToggleSwitch } from '../../components/common/ToggleSwitch';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { ServerId } from '../../shared/types';
import { formatDateTime } from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface SettingsRow {
  website_title: string;
  maintenance_mode: number;
  maintenance_message: string;
  announcement: string;
  allow_admin_during_maintenance: number;
  default_server_id: ServerId;
  updated_at: string | null;
  updated_by: string | null;
}

const SERVER_OPTIONS: { id: ServerId; label: string }[] = [
  { id: 'brazil', label: 'Brazil' },
  { id: 'india', label: 'India' },
  { id: 'singapore', label: 'Singapore' },
  { id: 'europe', label: 'Europe' },
  { id: 'bangladesh', label: 'Bangladesh' },
];

export const WebsiteSettingsPage: React.FC = () => {
  const { can } = useAdminAuth();
  const { addToast } = useToast();
  const canManage = can('settings.manage');

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [websiteTitle, setWebsiteTitle] = useState('PRIME WIRE PRO');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maintenanceMessage, setMaintenanceMessage] = useState('');
  const [announcement, setAnnouncement] = useState('');
  const [allowAdminDuringMaintenance, setAllowAdminDuringMaintenance] = useState(true);
  const [defaultServerId, setDefaultServerId] = useState<ServerId>('singapore');
  const [meta, setMeta] = useState<{ updatedAt: string | null; updatedBy: string | null }>({
    updatedAt: null,
    updatedBy: null,
  });

  const loadSettings = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{ settings: SettingsRow }>('/api/admin/settings', {
        scope: 'admin',
      });
      const s = res.settings;
      setWebsiteTitle(s.website_title);
      setMaintenanceMode(s.maintenance_mode === 1);
      setMaintenanceMessage(s.maintenance_message ?? '');
      setAnnouncement(s.announcement ?? '');
      setAllowAdminDuringMaintenance(s.allow_admin_during_maintenance === 1);
      setDefaultServerId(s.default_server_id);
      setMeta({ updatedAt: s.updated_at, updatedBy: s.updated_by });
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to load website settings',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManage) return;
    setSaving(true);
    try {
      await apiRequest('/api/admin/settings', {
        method: 'PATCH',
        scope: 'admin',
        body: {
          websiteTitle: websiteTitle.trim() || 'PRIME WIRE PRO',
          maintenanceMode,
          maintenanceMessage: maintenanceMessage.trim(),
          announcement: announcement.trim(),
          allowAdminDuringMaintenance,
          defaultServerId,
        },
      });
      addToast({
        type: 'success',
        title: 'Website settings updated',
        description: maintenanceMode
          ? 'Public website is currently in Maintenance Mode.'
          : 'Public website is online.',
      });
      await loadSettings();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Failed to save settings',
        description: err instanceof ApiError ? err.message : undefined,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Website Settings & Maintenance Mode
          </h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Control public availability, announcements, default region, and maintenance lock.
          </p>
        </div>
        <button
          type="button"
          onClick={loadSettings}
          className="self-start sm:self-auto min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 inline-flex items-center gap-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {maintenanceMode && (
        <div className="rounded-2xl bg-amber-500/10 border border-amber-500/35 p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-100 leading-relaxed">
            <p className="font-semibold text-amber-200">Maintenance Mode Active</p>
            <p className="mt-0.5">
              Public logins, user sessions, and subscription endpoints return 503 Maintenance Mode.
              This separate Admin Dashboard remains operational.
            </p>
          </div>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-5 max-w-3xl">
        <section className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Public Maintenance Mode
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Immediately block public authentication and subscription imports with a custom notice.
              </p>
            </div>
            <ToggleSwitch
              checked={maintenanceMode}
              disabled={!canManage}
              label="Toggle Maintenance Mode"
              onChange={() => setMaintenanceMode((prev) => !prev)}
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Maintenance Message
            </label>
            <textarea
              rows={3}
              value={maintenanceMessage}
              disabled={!canManage}
              onChange={(e) => setMaintenanceMessage(e.target.value)}
              placeholder="System maintenance is currently in progress. Please check back shortly."
              className="w-full p-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-purple-500 disabled:opacity-60"
            />
          </div>

          <div className="flex items-center justify-between gap-4 pt-2 border-t border-zinc-800/70">
            <div>
              <p className="text-xs font-medium text-zinc-200">
                Allow Administrator Console During Maintenance
              </p>
              <p className="text-[11px] text-zinc-500">
                Keeps the independent Admin Dashboard accessible while public access is paused.
              </p>
            </div>
            <ToggleSwitch
              checked={allowAdminDuringMaintenance}
              disabled={!canManage}
              label="Allow admin during maintenance"
              onChange={() => setAllowAdminDuringMaintenance((prev) => !prev)}
            />
          </div>
        </section>

        <section className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-purple-400" />
            <h2 className="font-display text-base font-semibold text-white">General Configuration</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                Website Title
              </label>
              <input
                type="text"
                value={websiteTitle}
                disabled={!canManage}
                onChange={(e) => setWebsiteTitle(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-purple-500 disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                Default Server Region
              </label>
              <select
                value={defaultServerId}
                disabled={!canManage}
                onChange={(e) => setDefaultServerId(e.target.value as ServerId)}
                className="w-full h-11 px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-zinc-100 focus:outline-none focus:border-purple-500 disabled:opacity-60"
              >
                {SERVER_OPTIONS.map((srv) => (
                  <option key={srv.id} value={srv.id}>
                    {srv.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Public Announcement Banner
            </label>
            <input
              type="text"
              value={announcement}
              disabled={!canManage}
              onChange={(e) => setAnnouncement(e.target.value)}
              placeholder="Optional announcement displayed to signed-in users"
              className="w-full h-11 px-3.5 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-purple-500 disabled:opacity-60"
            />
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-zinc-800/70">
            <p className="text-xs text-zinc-500">
              {meta.updatedAt
                ? `Last saved ${formatDateTime(meta.updatedAt)}${
                    meta.updatedBy ? ` by ${meta.updatedBy}` : ''
                  }`
                : 'Default settings'}
            </p>
            {canManage && (
              <button
                type="submit"
                disabled={saving}
                className="min-h-[44px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-xs font-semibold text-white inline-flex items-center justify-center gap-2 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving Settings...' : 'Save Settings'}</span>
              </button>
            )}
          </div>
        </section>
      </form>
    </div>
  );
};
