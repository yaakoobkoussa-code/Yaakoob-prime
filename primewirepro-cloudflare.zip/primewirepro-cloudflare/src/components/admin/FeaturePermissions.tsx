import React from 'react';
import { Check, Crosshair, Radar } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { ServerRegionId } from '../../types';
import { ToggleSwitch } from '../common/ToggleSwitch';

export const FeaturePermissions: React.FC = () => {
  const { features, servers, updateFeature } = useAppState();

  const toggleServerForFeature = (featureId: typeof features[number]['id'], serverId: ServerRegionId) => {
    const feat = features.find((f) => f.id === featureId);
    if (!feat) return;
    const has = feat.allowedServers.includes(serverId);
    updateFeature(featureId, {
      allowedServers: has
        ? feat.allowedServers.filter((id) => id !== serverId)
        : [...feat.allowedServers, serverId],
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Feature Permissions</h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Configure global availability and regional permissions for ONLY AIM POINT and AIM POINT
          AND MOCO MARK.
        </p>
      </div>

      {/* Strictly ONLY the 2 requested features */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {features.map((feat) => {
          const Icon = feat.id === 'only_aim_point' ? Crosshair : Radar;

          return (
            <section
              key={feat.id}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-5 sm:p-6 space-y-5"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-purple-600/15 border border-purple-500/30 flex items-center justify-center text-purple-300 shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-display text-base font-bold text-white">{feat.title}</h2>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      {feat.globallyEnabled ? 'Globally Enabled' : 'Globally Disabled'}
                    </p>
                  </div>
                </div>

                <ToggleSwitch
                  checked={feat.globallyEnabled}
                  label={`Enable ${feat.title} globally`}
                  onChange={() =>
                    updateFeature(feat.id, { globallyEnabled: !feat.globallyEnabled })
                  }
                />
              </div>

              <p className="text-xs text-zinc-400 leading-relaxed">{feat.description}</p>

              <div className="flex items-center justify-between gap-4 rounded-xl bg-[#07070A] border border-zinc-800/80 px-4 py-3">
                <div>
                  <p className="text-xs font-medium text-zinc-200">Default New-Key Authorization</p>
                  <p className="text-[11px] text-zinc-500">
                    Pre-select this feature when generating keys
                  </p>
                </div>
                <ToggleSwitch
                  checked={feat.defaultAuthorized}
                  label={`Default authorize ${feat.title}`}
                  onChange={() =>
                    updateFeature(feat.id, { defaultAuthorized: !feat.defaultAuthorized })
                  }
                />
              </div>

              <div>
                <p className="text-xs font-medium text-zinc-300 mb-2">Enabled Server Regions</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {servers.map((srv) => {
                    const enabled = feat.allowedServers.includes(srv.id);
                    return (
                      <button
                        key={srv.id}
                        type="button"
                        onClick={() => toggleServerForFeature(feat.id, srv.id)}
                        className={`min-h-[40px] px-3 rounded-xl border text-xs flex items-center justify-between gap-1.5 transition-colors ${
                          enabled
                            ? 'bg-purple-600/15 border-purple-500/50 text-white'
                            : 'bg-[#07070A] border-zinc-800 text-zinc-500'
                        }`}
                      >
                        <span className="truncate">
                          {srv.flag} {srv.name}
                        </span>
                        {enabled && <Check className="w-3.5 h-3.5 text-purple-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
