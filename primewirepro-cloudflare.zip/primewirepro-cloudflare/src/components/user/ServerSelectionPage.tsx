import React from 'react';
import { motion } from 'motion/react';
import { Activity, ArrowLeft, Check, Globe, Lock } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { ServerRegion } from '../../types';

interface ServerSelectionPageProps {
  onBack: () => void;
}

export const ServerSelectionPage: React.FC<ServerSelectionPageProps> = ({ onBack }) => {
  const { servers, keys, userSession, selectUserServer } = useAppState();
  const activeKey = keys.find((k) => k.id === userSession?.keyRecordId);

  const getStatusMeta = (server: ServerRegion) => {
    if (server.status === 'maintenance') {
      return {
        label: 'Maintenance',
        className: 'text-rose-400',
      };
    }
    if (server.status === 'high_load') {
      return {
        label: 'Elevated Load',
        className: 'text-amber-400',
      };
    }
    return {
      label: 'Operational',
      className: 'text-emerald-400',
    };
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back to dashboard"
            className="min-w-[44px] min-h-[44px] rounded-xl bg-[#111116] hover:bg-white/5 border border-white/10 flex items-center justify-center text-zinc-200 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-white">
              Server Selection
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              Choose one of the 5 demonstration server regions
            </p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-400">
          <Globe className="w-4 h-4 text-purple-400" />
          <span>5 Regional Nodes</span>
        </div>
      </div>

      {/* Exactly 5 Server Cards: Brazil, India, Singapore, Europe, Bangladesh */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {servers.map((server) => {
          const isSelected = userSession?.selectedServerId === server.id;
          const isPermitted = activeKey ? activeKey.allowedServers.includes(server.id) : true;
          const isMaintenance = server.status === 'maintenance';
          const statusMeta = getStatusMeta(server);
          const disabled = !isPermitted || isMaintenance;

          return (
            <motion.button
              key={server.id}
              type="button"
              disabled={disabled}
              whileTap={disabled ? undefined : { scale: 0.985 }}
              onClick={() => selectUserServer(server.id)}
              className={`relative text-left rounded-2xl p-5 border transition-all min-h-[132px] flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#15111E] border-purple-500 shadow-[0_0_28px_rgba(168,85,247,0.22)]'
                  : disabled
                  ? 'bg-[#0D0D11] border-white/5 opacity-55 cursor-not-allowed'
                  : 'bg-[#111116] border-white/8 hover:border-purple-500/40 hover:bg-[#14141B]'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <span
                    className="text-3xl leading-none select-none"
                    role="img"
                    aria-label={`${server.name} flag`}
                  >
                    {server.flag}
                  </span>
                  <div>
                    <h2 className="font-display text-base font-semibold text-white">
                      {server.name}
                    </h2>
                    <div className="flex items-center gap-2 text-xs text-zinc-400 mt-0.5">
                      <span className="font-mono">{server.code}</span>
                      <span aria-hidden="true">·</span>
                      <span className={statusMeta.className}>{statusMeta.label}</span>
                    </div>
                  </div>
                </div>

                {/* Selection Indicator */}
                <div
                  className={`w-7 h-7 rounded-full border flex items-center justify-center shrink-0 transition-all ${
                    isSelected
                      ? 'bg-purple-600 border-purple-400 text-white shadow-[0_0_12px_rgba(168,85,247,0.65)]'
                      : !isPermitted
                      ? 'bg-zinc-900 border-white/10 text-zinc-500'
                      : 'bg-[#080808] border-white/15 text-transparent'
                  }`}
                >
                  {!isPermitted ? <Lock className="w-3.5 h-3.5" /> : <Check className="w-4 h-4" />}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-white/8 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-zinc-400">
                  <Activity className="w-3.5 h-3.5 text-purple-400" />
                  <span className="tabular-nums font-mono">{server.simulatedLatencyMs} ms</span>
                  <span className="text-zinc-500">(Demo)</span>
                </div>
                <span className="text-zinc-400 tabular-nums">
                  {isSelected
                    ? 'Selected'
                    : !isPermitted
                    ? 'Not in key plan'
                    : `${Math.round((server.activeUsersDemo / server.capacityLimit) * 100)}% load`}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
};
