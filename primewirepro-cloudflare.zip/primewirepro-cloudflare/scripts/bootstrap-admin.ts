import dotenv from 'dotenv';

dotenv.config();

async function main() {
  const apiBase = (process.env.VITE_API_BASE_URL || `http://127.0.0.1:${process.env.PORT ?? 3000}`).replace(
    /\/$/,
    ''
  );
  const setupSecret = process.env.BOOTSTRAP_SETUP_SECRET?.trim() ?? '';
  const username = (process.env.BOOTSTRAP_ADMIN_USERNAME?.trim() || 'primeadmin');
  const email = process.env.BOOTSTRAP_ADMIN_EMAIL?.trim() ?? '';
  const password = process.env.BOOTSTRAP_ADMIN_PASSWORD ?? '';

  if (!setupSecret || setupSecret.includes('replace-with')) {
    console.error('Error: BOOTSTRAP_SETUP_SECRET is missing or still a placeholder in .env.');
    process.exit(1);
  }
  if (!email || !email.includes('@')) {
    console.error('Error: Set a valid BOOTSTRAP_ADMIN_EMAIL in .env before running bootstrap.');
    process.exit(1);
  }
  if (password.length < 10) {
    console.error('Error: Set a strong BOOTSTRAP_ADMIN_PASSWORD (min 10 chars) in .env.');
    process.exit(1);
  }

  const res = await fetch(`${apiBase}/api/admin/bootstrap`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Bootstrap-Secret': setupSecret,
    },
    body: JSON.stringify({
      setupSecret,
      username,
      email,
      password,
    }),
  });

  const payload = (await res.json().catch(() => ({}))) as {
    ok?: boolean;
    error?: string;
    username?: string;
    roleId?: string;
  };

  if (!res.ok) {
    console.error(`Bootstrap failed (${res.status}): ${payload.error ?? 'Unknown error'}`);
    process.exit(1);
  }

  console.log(`Initial ${payload.roleId} created for username "${payload.username}" via ${apiBase}.`);
}

main().catch((err) => {
  console.error('Bootstrap error:', err instanceof Error ? err.message : err);
  process.exit(1);
});
