import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      {
        name: 'rename-admin-html-to-index',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) return;
          const outDir = path.resolve(__dirname, 'dist-admin');
          const adminHtml = path.join(outDir, 'admin.html');
          const indexHtml = path.join(outDir, 'index.html');
          if (fs.existsSync(adminHtml)) {
            fs.renameSync(adminHtml, indexHtml);
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      outDir: 'dist-admin',
      emptyOutDir: true,
      rollupOptions: {
        input: path.resolve(__dirname, 'admin.html'),
      },
    },
  };
});
