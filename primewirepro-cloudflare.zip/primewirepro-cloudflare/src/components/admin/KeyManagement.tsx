import React, { useMemo, useState } from 'react';
import {
  Ban,
  CheckCircle2,
  Copy,
  Download,
  PauseCircle,
  Search,
  Trash2,
} from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { KeyStatus } from '../../types';
import { downloadCsv, formatDateShort } from '../../utils/formatters';

export const KeyManagement: React.FC = () => {
  const { keys, distributors, updateKeyStatus, deleteKey, addToast } = useAppState();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | KeyStatus>('all');
  const [distFilter, setDistFilter] = useState<string>('all');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return keys.filter((k) => {
      if (statusFilter !== 'all' && k.status !== statusFilter) return false;
      if (distFilter !== 'all' && k.distributorId !== distFilter) return false;
      if (q && !k.key.toLowerCase().includes(q) && !k.distributorName.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [keys, search, statusFilter, distFilter]);

  const copyKey = async (key: string) => {
    try {
      await navigator.clipboard.writeText(key);
    } catch {
      // Ignore sandbox restriction
    }
    addToast({ type: 'success', title: 'Copied product key', description: key });
  };

  const handleExport = () => {
    downloadCsv(
      'prime-wire-pro-demo-keys.csv',
      filtered.map((k) => ({
        key: k.key,
        status: k.status,
        durationDays: k.durationDays,
        devicesUsed: k.devicesUsed,
        deviceLimit: k.deviceLimit,
        distributor: k.distributorName,
        activationRule: k.activationRule,
        expiresAt: k.expiresAt,
      }))
    );
    addToast({
      type: 'success',
      title: 'Exported demonstration keys',
      description: `${filtered.length} records saved as CSV.`,
    });
  };

  const statusColor = (status: KeyStatus) => {
    if (status === 'active') return 'text-emerald-400';
    if (status === 'suspended') return 'text-amber-400';
    return 'text-rose-400';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Key Management</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Search, suspend, revoke, delete, copy, or export demonstration product keys.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExport}
          disabled={filtered.length === 0}
          className="self-start sm:self-auto min-h-[44px] px-4 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-50 border border-zinc-800 text-xs font-semibold text-white inline-flex items-center gap-2 transition-colors"
        >
          <Download className="w-4 h-4 text-purple-400" />
          <span>Export Keys (CSV)</span>
        </button>
      </div>

      {/* Filters */}
      <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1 flex items-center">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search PMWR key or distributor..."
            className="w-full min-h-[44px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(['all', 'active', 'suspended', 'expired', 'revoked'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`min-h-[40px] px-3 rounded-xl text-xs font-medium capitalize border transition-colors ${
                statusFilter === st
                  ? 'bg-purple-600/20 border-purple-500 text-purple-200'
                  : 'bg-[#07070A] border-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}

          <select
            aria-label="Filter by distributor"
            value={distFilter}
            onChange={(e) => setDistFilter(e.target.value)}
            className="min-h-[40px] px-3 rounded-xl bg-[#07070A] border border-zinc-800 text-xs text-zinc-200 focus:outline-none focus:border-purple-500"
          >
            <option value="all">All Distributors</option>
            {distributors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Empty State */}
      {filtered.length === 0 ? (
        <div className="rounded-2xl bg-[#101015] border border-zinc-800 p-10 text-center">
          <p className="text-sm font-medium text-zinc-300">No matching keys found</p>
          <p className="text-xs text-zinc-500 mt-1">Adjust your search or status filters.</p>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden lg:block rounded-2xl bg-[#101015] border border-zinc-800/90 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 bg-[#0B0B10]">
                    <th className="py-3.5 px-4 font-medium">Product Key</th>
                    <th className="py-3.5 px-4 font-medium">Status</th>
                    <th className="py-3.5 px-4 font-medium">Distributor</th>
                    <th className="py-3.5 px-4 font-medium">Devices</th>
                    <th className="py-3.5 px-4 font-medium">Features</th>
                    <th className="py-3.5 px-4 font-medium">Expires</th>
                    <th className="py-3.5 px-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/70">
                  {filtered.map((item) => (
                    <tr key={item.id} className="hover:bg-white/[0.02]">
                      <td className="py-3.5 px-4 font-mono text-zinc-100 whitespace-nowrap">
                        {item.key}
                      </td>
                      <td className={`py-3.5 px-4 font-medium capitalize ${statusColor(item.status)}`}>
                        {item.status}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-300">{item.distributorName}</td>
                      <td className="py-3.5 px-4 text-zinc-300 tabular-nums">
                        {item.devicesUsed}/{item.deviceLimit}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-400">
                        {item.allowedFeatures.length === 2
                          ? 'Both Features'
                          : item.allowedFeatures[0] === 'only_aim_point'
                          ? 'ONLY AIM POINT'
                          : 'AIM POINT & MOCO'}
                      </td>
                      <td className="py-3.5 px-4 text-zinc-400 tabular-nums whitespace-nowrap">
                        {formatDateShort(item.expiresAt)}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => copyKey(item.key)}
                            title="Copy key"
                            className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-white/10 text-zinc-400 hover:text-white flex items-center justify-center"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          {item.status !== 'active' ? (
                            <button
                              type="button"
                              onClick={() => updateKeyStatus(item.id, 'active')}
                              title="Activate key"
                              className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-emerald-500/15 text-zinc-400 hover:text-emerald-400 flex items-center justify-center"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => updateKeyStatus(item.id, 'suspended')}
                              title="Suspend key"
                              className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-amber-500/15 text-zinc-400 hover:text-amber-400 flex items-center justify-center"
                            >
                              <PauseCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {item.status !== 'revoked' && (
                            <button
                              type="button"
                              onClick={() => updateKeyStatus(item.id, 'revoked')}
                              title="Revoke key"
                              className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-rose-500/15 text-zinc-400 hover:text-rose-400 flex items-center justify-center"
                            >
                              <Ban className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => deleteKey(item.id)}
                            title="Delete key"
                            className="min-w-[34px] min-h-[34px] rounded-lg hover:bg-rose-500/15 text-zinc-500 hover:text-rose-400 flex items-center justify-center"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile / Tablet Management Cards */}
          <div className="lg:hidden grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-mono text-sm text-white truncate">{item.key}</p>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      {item.distributorName} · {item.durationDays}d
                    </p>
                  </div>
                  <span className={`text-xs font-semibold capitalize ${statusColor(item.status)}`}>
                    {item.status}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs text-zinc-400 pt-2 border-t border-zinc-800/70">
                  <span className="tabular-nums">
                    Devices: {item.devicesUsed}/{item.deviceLimit}
                  </span>
                  <span className="tabular-nums">Exp: {formatDateShort(item.expiresAt)}</span>
                </div>

                <div className="grid grid-cols-4 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => copyKey(item.key)}
                    className="min-h-[38px] rounded-lg bg-white/5 hover:bg-white/10 text-xs text-zinc-200 flex items-center justify-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      updateKeyStatus(item.id, item.status === 'active' ? 'suspended' : 'active')
                    }
                    className="min-h-[38px] rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-xs text-amber-300 flex items-center justify-center"
                  >
                    {item.status === 'active' ? 'Suspend' : 'Activate'}
                  </button>
                  <button
                    type="button"
                    onClick={() => updateKeyStatus(item.id, 'revoked')}
                    disabled={item.status === 'revoked'}
                    className="min-h-[38px] rounded-lg bg-rose-500/10 hover:bg-rose-500/20 disabled:opacity-40 text-xs text-rose-300 flex items-center justify-center"
                  >
                    Revoke
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteKey(item.id)}
                    className="min-h-[38px] rounded-lg bg-white/5 hover:bg-rose-500/20 text-xs text-zinc-400 hover:text-rose-300 flex items-center justify-center"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};
