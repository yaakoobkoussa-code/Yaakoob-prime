import crypto from 'crypto';
import dotenv from 'dotenv';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import worker from './workers/api/src/index';
import { LocalD1Database } from './workers/api/src/localD1';
import { WorkerEnv } from './workers/api/src/types';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(__dirname, '.local-data');
const DB_PATH = path.join(DATA_DIR, 'primewirepro.sqlite');
const SECRETS_PATH = path.join(DATA_DIR, 'dev-secrets.json');
const MIGRATIONS_DIR = path.resolve(__dirname, 'workers/migrations');

function getOrCreateDevSecrets(): { sessionSecret: string; bootstrapSecret: string } {
  if (process.env.SESSION_SECRET && process.env.BOOTSTRAP_SETUP_SECRET) {
    return {
      sessionSecret: process.env.SESSION_SECRET,
      bootstrapSecret: process.env.BOOTSTRAP_SETUP_SECRET,
    };
  }
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(SECRETS_PATH)) {
    const existing = JSON.parse(fs.readFileSync(SECRETS_PATH, 'utf8')) as {
      sessionSecret?: string;
      bootstrapSecret?: string;
    };
    if (existing.sessionSecret && existing.bootstrapSecret) {
      return {
        sessionSecret: process.env.SESSION_SECRET ?? existing.sessionSecret,
        bootstrapSecret: process.env.BOOTSTRAP_SETUP_SECRET ?? existing.bootstrapSecret,
      };
    }
  }
  const generated = {
    sessionSecret: process.env.SESSION_SECRET ?? crypto.randomBytes(32).toString('hex'),
    bootstrapSecret: process.env.BOOTSTRAP_SETUP_SECRET ?? crypto.randomBytes(24).toString('hex'),
  };
  fs.writeFileSync(SECRETS_PATH, JSON.stringify(generated, null, 2), { mode: 0o600 });
  return generated;
}

async function startServer() {
  const localDb = new LocalD1Database(DB_PATH);
  localDb.runMigrations(MIGRATIONS_DIR);

  const secrets = getOrCreateDevSecrets();
  const workerEnv: WorkerEnv = {
    DB: localDb,
    SESSION_SECRET: secrets.sessionSecret,
    BOOTSTRAP_SETUP_SECRET: secrets.bootstrapSecret,
    PUBLIC_ORIGIN: process.env.PUBLIC_ORIGIN ?? 'https://primewirepro.pages.dev',
    ADMIN_ORIGIN: process.env.ADMIN_ORIGIN ?? 'https://primewirepro-dashboard.pages.dev',
    ALLOW_LOCAL_DEV_ORIGINS: 'true',
  };

  const app = express();
  app.set('trust proxy', true);

  // Read raw body for /api/* and forward into Cloudflare Worker fetch handler
  app.use('/api', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
    try {
      const protocol = req.protocol || 'http';
      const host = req.get('host') || 'localhost:3000';
      const fullUrl = `${protocol}://${host}${req.originalUrl}`;

      const headers = new Headers();
      for (const [k, v] of Object.entries(req.headers)) {
        if (typeof v === 'string') headers.set(k, v);
        else if (Array.isArray(v)) headers.set(k, v.join(', '));
      }

      const hasBody = !['GET', 'HEAD'].includes(req.method.toUpperCase());
      const bodyBuffer =
        hasBody && Buffer.isBuffer(req.body) && req.body.length > 0
          ? new Uint8Array(req.body)
          : undefined;

      const webReq = new Request(fullUrl, {
        method: req.method,
        headers,
        body: bodyBuffer,
      });

      const webRes = await worker.fetch(webReq, workerEnv);
      res.status(webRes.status);

      const getSetCookie = (webRes.headers as unknown as { getSetCookie?: () => string[] })
        .getSetCookie;
      const cookies = typeof getSetCookie === 'function' ? getSetCookie.call(webRes.headers) : [];
      webRes.headers.forEach((value, key) => {
        if (key.toLowerCase() !== 'set-cookie') {
          res.setHeader(key, value);
        }
      });
      if (cookies.length > 0) {
        res.setHeader('Set-Cookie', cookies);
      }

      const buf = Buffer.from(await webRes.arrayBuffer());
      res.send(buf);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Server error',
      });
    }
  });

  app.get('/download/primewirepro-cloudflare.zip', (_req, res) => {
    const zipFile = path.resolve(__dirname, 'release/primewirepro-cloudflare.zip');
    if (!fs.existsSync(zipFile)) {
      res.status(404).json({ error: 'Release archive has not been built yet.' });
      return;
    }
    res.download(zipFile, 'primewirepro-cloudflare.zip');
  });

  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    app.use(vite.middlewares);

    app.use(async (req, res, next) => {
      if (req.originalUrl.startsWith('/api')) return next();
      try {
        const isAdminRoute = req.path === '/admin' || req.path.startsWith('/admin/');
        const templateFile = isAdminRoute ? 'admin.html' : 'index.html';
        let html = fs.readFileSync(path.resolve(__dirname, templateFile), 'utf8');
        html = await vite.transformIndexHtml(req.originalUrl, html);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const publicDist = path.resolve(__dirname, 'dist');
    const adminDist = path.resolve(__dirname, 'dist-admin');

    app.use('/admin', express.static(adminDist));
    app.use(express.static(publicDist));

    app.get('/admin*', (_req, res) => {
      res.sendFile(path.join(adminDist, 'index.html'));
    });

    app.get('*', (_req, res) => {
      res.sendFile(path.join(publicDist, 'index.html'));
    });
  }

  const port = Number(process.env.PORT ?? 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`PRIME WIRE PRO full-stack server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
