import { createRoot } from 'react-dom/client';
import { PublicApp } from './public/PublicApp';
import './index.css';

createRoot(document.getElementById('root')!).render(<PublicApp />);
