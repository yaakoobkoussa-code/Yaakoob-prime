import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertTriangle,
  Calendar,
  ChevronRight,
  Clock,
  Copy,
  Crosshair,
  Eye,
  EyeOff,
  Globe,
  Laptop,
  Loader2,
  Plus,
  Shield,
  Sliders,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import {
  computeCountdown,
  formatDateShort,
  maskProductKey,
} from '../../utils/formatters';
import { usePublicAuth } from '../hooks/usePublicAuth';

interface PublicHomeDashboardProps {
  onOpenServers: () => void;
  onOpenFeatures: () => void;
}

export const PublicHomeDashboard: React.FC<PublicHomeDashboardProps> = ({
  onOpenServers,
  onOpenFeatures,
}) => {
  const { userData, refreshUser } = usePublicAuth();
  const { addToast } = useToast();

  const [showKey, setShowKey] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [missingHappModal, setMissingHappModal] = useState(false);

  const [countdown, setCountdown] = useState(() =>
    userData
      ? computeCountdown(userData.credential.expiresAt, userData.credential.activatedAt)
      : { days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: false, progressPercent: 0 }
  );

  useEffect(() => {
    if (!userData) return;
    setCountdown(
      computeCountdown(userData.credential.expiresAt, userData.credential.activatedAt)
    );
    const timer = window.setInterval(() => {
      const next = computeCountdown(
        userData.credential.expiresAt,
        userData.credential.activatedAt
      );
      setCountdown(next);
      if (next.isExpired) {
        refreshUser();
      }
    }, 1000);
    return () => window.clearInterval(timer);
  }, [userData, refreshUser]);

  if (!userData) return null;

  const { session, credential, device, servers, features } = userData;
  const currentServer =
    servers.find((s) => s.id === session.selectedServerId) ?? servers[0];
  const currentFeature =
    features.find((f) => f.id === session.activeFeatureId) ?? null;

  const displayedKey = showKey
    ? credential.code
    : session.authType === 'product_key'
    ? maskProductKey(credential.code)
    : `${credential.code.slice(0, 3)}••••`;

  const handleCopyKey = async () => {
    try {
      await navigator.clipboard.writeText(credential.code);
      addToast({ type: 'success', title: 'Access code copied' });
    } catch {
      addToast({ type: 'info', title: 'Copy unavailable in browser context' });
    }
  };

  // Official Happ Subscription Import — ONE button only (ADD SUBSCRIPTION), NO Copy Link
  const handleAddSubscription = async () => {
    setImportError(null);
    if (!currentFeature) {
      const msg = 'Select AIM POINT or AIM POINT AND MOCO MARK on the Features page first.';
      setImportError(msg);
      addToast({ type: 'warning', title: 'No feature selected', description: msg });
      return;
    }

    setImporting(true);
    try {
      const res = await apiRequest<{
        ok: boolean;
        happDeepLink: string;
      }>('/api/subscription/resolve', {
        method: 'POST',
        scope: 'user',
        body: {
          serverId: currentServer.id,
          featureId: currentFeature.id,
        },
      });

      let appOpened = false;
      const onVisibilityChange = () => {
        if (document.hidden) appOpened = true;
      };
      const onBlur = () => {
        appOpened = true;
      };
      document.addEventListener('visibilitychange', onVisibilityChange);
      window.addEventListener('blur', onBlur);

      window.location.href = res.happDeepLink;

      window.setTimeout(() => {
        document.removeEventListener('visibilitychange', onVisibilityChange);
        window.removeEventListener('blur', onBlur);
        setImporting(false);
        if (!appOpened) {
          setMissingHappModal(true);
        }
      }, 1800);
    } catch (err) {
      setImporting(false);
      const message =
        err instanceof ApiError ? err.message : 'SUBSCRIPTION NOT AVAILABLE';
      setImportError(message);
      addToast({
        type: 'error',
        title: message === 'SUBSCRIPTION NOT AVAILABLE' ? 'SUBSCRIPTION NOT AVAILABLE' : 'Import failed',
        description:
          message === 'SUBSCRIPTION NOT AVAILABLE'
            ? 'This region and feature subscription is currently unavailable or disabled.'
            : message,
      });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-purple-400">
            {session.authType === 'product_key'
              ? 'Individual Product Key · 1-Device Lock'
              : 'Universal Public Access'}
          </p>
          <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold tracking-tight text-white text-balance">
            Welcome back to {userData.settings.websiteTitle}
          </h1>
          <p className="mt-1 text-sm text-zinc-400">
            Select your region and feature profile, then import into Happ.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenServers}
          className="self-start sm:self-auto min-h-[44px] px-4 py-2 rounded-xl bg-[#121218] hover:bg-purple-500/12 border border-white/10 hover:border-purple-500/40 flex items-center gap-2.5 text-sm font-medium text-white transition-colors"
        >
          <span className="text-lg leading-none">{currentServer.flag}</span>
          <span>{currentServer.name}</span>
          <ChevronRight className="w-4 h-4 text-zinc-400" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Subscription Countdown Card */}
        <section className="lg:col-span-7 rounded-2xl bg-[#111116] border border-white/8 p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs text-zinc-400">
                <Clock className="w-4 h-4 text-purple-400" />
                <span>Subscription Countdown</span>
              </div>
              <div className="mt-3 flex items-baseline gap-4 flex-wrap">
                <div>
                  <span className="font-display text-4xl sm:text-5xl font-bold text-white tabular-nums">
                    {countdown.days}
                  </span>
                  <span className="ml-1.5 text-sm text-zinc-400">Days</span>
                </div>
                <div>
                  <span className="font-display text-4xl sm:text-5xl font-bold text-purple-400 tabular-nums">
                    {String(countdown.hours).padStart(2, '0')}
                  </span>
                  <span className="ml-1.5 text-sm text-zinc-400">Hours</span>
                </div>
                <div className="text-lg font-mono text-zinc-300 tabular-nums">
                  {String(countdown.minutes).padStart(2, '0')}m{' '}
                  {String(countdown.seconds).padStart(2, '0')}s
                </div>
              </div>
            </div>

            <span className="text-xs font-medium text-emerald-400 whitespace-nowrap shrink-0">
              {countdown.isExpired ? 'Expired' : 'Active Plan'}
            </span>
          </div>

          <div className="mt-6">
            <div className="h-2 w-full rounded-full bg-white/8 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-purple-600 to-fuchsia-400 transition-all duration-500"
                style={{ width: `${countdown.progressPercent}%` }}
              />
            </div>
            <div className="mt-4 pt-4 border-t border-white/8 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Activated</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {formatDateShort(credential.activatedAt)}
                </p>
              </div>
              <div>
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Expires</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 tabular-nums">
                  {formatDateShort(credential.expiresAt)}
                </p>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <p className="text-zinc-500 flex items-center gap-1.5">
                  <Laptop className="w-3.5 h-3.5" />
                  <span>Device Binding</span>
                </p>
                <p className="mt-1 font-medium text-zinc-200 truncate">
                  {device.permanentBinding ? '1-Device Bound' : 'Multi-User Code'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Credential & Happ Subscription Import Column */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          <section className="rounded-2xl bg-[#111116] border border-white/8 p-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-zinc-400">
                {session.authType === 'product_key' ? 'Licensed Product Key' : 'Universal Access Code'}
              </span>
              <span className="text-xs text-zinc-400">{device.platform}</span>
            </div>

            <div className="mt-3 flex items-center justify-between gap-2 rounded-xl bg-[#080808] border border-white/8 px-3.5 py-2.5">
              <code className="font-mono text-sm text-zinc-100 tracking-wider truncate">
                {displayedKey}
              </code>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowKey((v) => !v)}
                  aria-label={showKey ? 'Hide key' : 'Show key'}
                  className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-white/8 text-zinc-400 hover:text-white flex items-center justify-center transition-colors"
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={handleCopyKey}
                  aria-label="Copy key"
                  className="min-w-[40px] min-h-[40px] rounded-lg hover:bg-purple-500/15 text-zinc-400 hover:text-purple-300 flex items-center justify-center transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>

          {/* Happ Subscription Import Card — ONE BUTTON ONLY: ADD SUBSCRIPTION */}
          <section className="flex-1 rounded-2xl bg-[#13101B] border border-purple-500/30 p-5 flex flex-col justify-between shadow-[0_0_32px_rgba(147,51,234,0.12)]">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-display text-base font-semibold text-white">
                    Happ Subscription Import
                  </h2>
                  <p className="text-xs text-zinc-400">Direct Happ deep-link authorization</p>
                </div>
              </div>
              <p className="mt-3 text-xs text-zinc-300 leading-relaxed">
                Imports the authorized configuration for{' '}
                <span className="text-white font-medium">{currentServer.name}</span>
                {currentFeature ? ` · ${currentFeature.title}` : ' (select a feature first)'}.
              </p>

              {importError && (
                <div
                  role="alert"
                  className="mt-3 rounded-xl bg-rose-500/10 border border-rose-500/30 px-3 py-2 text-xs text-rose-200 flex items-start gap-2"
                >
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{importError}</span>
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={importing}
              onClick={handleAddSubscription}
              className="mt-4 w-full min-h-[46px] rounded-xl bg-purple-600 hover:bg-purple-500 active:scale-[0.99] disabled:opacity-60 text-sm font-semibold text-white shadow-[0_0_20px_rgba(147,51,234,0.35)] flex items-center justify-center gap-2 transition-all"
            >
              {importing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Opening Happ...</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>ADD SUBSCRIPTION</span>
                </>
              )}
            </button>
          </section>
        </div>
      </div>

      {/* Bottom 2 Interactive Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <button
          type="button"
          onClick={onOpenServers}
          className="text-left rounded-2xl bg-[#111116] hover:bg-[#15151C] border border-white/8 hover:border-purple-500/40 p-5 flex items-center justify-between gap-4 transition-all group min-h-[96px]"
        >
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-[#080808] border border-white/10 flex items-center justify-center text-2xl shrink-0">
              {currentServer.flag}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <Globe className="w-3.5 h-3.5 text-purple-400" />
                <span>Current Server Region</span>
              </div>
              <p className="mt-0.5 font-display text-lg font-semibold text-white truncate">
                {currentServer.name}
              </p>
              <p className="text-xs text-zinc-400 font-mono">
                {currentServer.code} · {currentServer.enabled ? 'Enabled' : 'Disabled'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-medium text-purple-400 shrink-0">
            <span>Change</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </button>

        <button
          type="button"
          onClick={onOpenFeatures}
          className="text-left rounded-2xl bg-[#111116] hover:bg-[#15151C] border border-white/8 hover:border-purple-500/40 p-5 flex items-center justify-between gap-4 transition-all group min-h-[96px]"
        >
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-[#080808] border border-white/10 flex items-center justify-center text-purple-400 shrink-0">
              {currentFeature ? (
                <Crosshair className="w-5 h-5" />
              ) : (
                <Sliders className="w-5 h-5 text-zinc-500" />
              )}
            </div>
            <div className="min-w-0">
              <div className="text-xs text-zinc-400">Current Active Feature</div>
              <p className="mt-0.5 font-display text-lg font-semibold text-white truncate">
                {currentFeature ? currentFeature.title : 'None Active'}
              </p>
              <p className="text-xs text-zinc-400">
                {currentFeature
                  ? 'Single active profile enforced'
                  : 'Select AIM POINT or AIM POINT AND MOCO MARK'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-medium text-purple-400 shrink-0">
            <span>Configure</span>
            <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </button>
      </div>

      {/* Missing Happ Installation Fallback Modal */}
      <Modal
        open={missingHappModal}
        onClose={() => setMissingHappModal(false)}
        title="Happ App Not Detected"
        subtitle="Install Happ on your device to complete subscription import"
      >
        <div className="space-y-4 text-sm text-zinc-300">
          <p className="leading-relaxed">
            Your browser did not hand off the <code className="font-mono text-purple-300">happ://</code>{' '}
            deep link to the Happ application. This usually means Happ is not installed on this device or
            deep-link handoff was blocked by your browser.
          </p>
          <div className="rounded-xl bg-[#080808] border border-white/10 p-4 text-xs space-y-2 text-zinc-400">
            <p className="font-semibold text-zinc-200">How to resolve:</p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Install the official Happ Proxy Utility from Google Play, App Store, or happ.su.</li>
              <li>Return to PRIME WIRE PRO in your mobile browser and tap ADD SUBSCRIPTION again.</li>
            </ol>
          </div>
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setMissingHappModal(false)}
              className="min-h-[44px] px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-sm font-semibold text-white"
            >
              Close
            </button>
          </div>
        </div>
      </Modal>
    </motion.div>
  );
};
