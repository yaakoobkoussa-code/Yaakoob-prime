import React, { useCallback, useEffect, useState } from 'react';
import { Ban, CheckCircle2, Smartphone, Unlink } from 'lucide-react';
import { ApiError, apiRequest } from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import { formatDateTime } from '../../utils/formatters';
import { useAdminAuth } from '../hooks/useAdminAuth';

interface DeviceRow {
  id: string;
  device_label: string;
  platform: string;
  user_agent: string;
  status: 'trusted' | 'blocked';
  first_seen_at: string;
  last_seen_at: string;
  bound_key_id: string | null;
  bound_key_code: string | null;
}

export const DeviceManagementPage: React.FC = () => {
  const { can } = useAdminAuth();
  const { addToast } = useToast();
  const [devices, setDevices] = useState<DeviceRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiRequest<{ devices: DeviceRow[] }>('/api/admin/devices', {
        scope: 'admin',
      });
      setDevices(res.devices);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const setStatus = async (id: string, status: 'trusted' | 'blocked') => {
    try {
      await apiRequest(`/api/admin/devices/${id}/status`, {
        method: 'POST',
        scope: 'admin',
        body: { status },
      });
      addToast({ type: 'success', title: `Device marked ${status}` });
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Update failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  const unbindKey = async (keyId: string) => {
    try {
      await apiRequest(`/api/admin/keys/${keyId}/unbind`, {
        method: 'POST',
        scope: 'admin',
      });
      addToast({ type: 'success', title: 'Device unbound from product key' });
      await load();
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Unbind failed',
        description: err instanceof ApiError ? err.message : undefined,
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-white">Device Management</h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Server-issued registered device credentials and permanent product-key bindings.
        </p>
      </div>

      {loading ? (
        <p className="text-sm text-zinc-400">Loading registered devices...</p>
      ) : devices.length === 0 ? (
        <div className="rounded-2xl bg-[#101015] border border-zinc-800 p-10 text-center">
          <p className="text-sm text-zinc-400">No devices registered yet.</p>
        </div>
      ) : (
        <div className="rounded-2xl bg-[#101015] border border-zinc-800/90 overflow-hidden">
          <div className="divide-y divide-zinc-800/70">
            {devices.map((d) => (
              <div
                key={d.id}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#07070A] border border-zinc-800 flex items-center justify-center text-purple-400 shrink-0">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-white truncate">{d.device_label}</p>
                      <span
                        className={`text-xs font-medium capitalize ${
                          d.status === 'trusted' ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        · {d.status}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      {d.platform} · <span className="font-mono">{d.id}</span> · Last seen{' '}
                      {formatDateTime(d.last_seen_at)}
                    </p>
                    <p className="text-xs text-zinc-500 mt-0.5">
                      Bound Key:{' '}
                      <span className="font-mono text-zinc-300">
                        {d.bound_key_code ?? 'None'}
                      </span>
                    </p>
                  </div>
                </div>

                {can('devices.unbind') && (
                  <div className="flex items-center gap-2 shrink-0">
                    {d.bound_key_id && (
                      <button
                        type="button"
                        onClick={() => unbindKey(d.bound_key_id!)}
                        className="min-h-[38px] px-3 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 text-xs font-medium text-purple-200 inline-flex items-center gap-1.5"
                      >
                        <Unlink className="w-3.5 h-3.5" />
                        <span>Unbind Key</span>
                      </button>
                    )}
                    {d.status === 'trusted' ? (
                      <button
                        type="button"
                        onClick={() => setStatus(d.id, 'blocked')}
                        className="min-h-[38px] px-3 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-xs font-medium text-rose-300 inline-flex items-center gap-1.5"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>Block</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setStatus(d.id, 'trusted')}
                        className="min-h-[38px] px-3 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-xs font-medium text-emerald-300 inline-flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Trust</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
