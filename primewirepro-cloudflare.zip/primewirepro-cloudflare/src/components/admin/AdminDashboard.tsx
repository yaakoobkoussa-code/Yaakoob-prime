import React from 'react';
import {
  Activity,
  Ban,
  Clock,
  KeyRound,
  ShieldCheck,
  Smartphone,
  UserCheck,
  Users,
} from 'lucide-react';
import { WEEKLY_KEY_TREND } from '../../data/demoData';
import { useAppState } from '../../hooks/useAppState';
import { AdminSection } from '../../types';
import { formatDateShort, formatDateTime, maskProductKey } from '../../utils/formatters';

interface AdminDashboardProps {
  onNavigateSection: (section: AdminSection) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateSection }) => {
  const { keys, distributors, devices, servers, securityLogs } = useAppState();

  const totalKeys = keys.length;
  const activeKeys = keys.filter((k) => k.status === 'active').length;
  const expiredKeys = keys.filter((k) => k.status === 'expired').length;
  const revokedKeys = keys.filter((k) => k.status === 'revoked').length;
  const activeSubscriptions = keys.filter(
    (k) => k.status === 'active' && k.activatedAt !== null
  ).length;
  const totalDistributors = distributors.length;
  const registeredDevices = devices.length;
  const totalUsers = keys.reduce((acc, k) => acc + Math.max(1, k.devicesUsed), 0);

  const stats = [
    { label: 'Total Generated Keys', value: totalKeys, icon: KeyRound, accent: 'text-purple-400' },
    { label: 'Active Keys', value: activeKeys, icon: ShieldCheck, accent: 'text-emerald-400' },
    { label: 'Expired Keys', value: expiredKeys, icon: Clock, accent: 'text-amber-400' },
    { label: 'Revoked Keys', value: revokedKeys, icon: Ban, accent: 'text-rose-400' },
    { label: 'Total Users (Demo)', value: totalUsers, icon: UserCheck, accent: 'text-zinc-200' },
    { label: 'Total Distributors', value: totalDistributors, icon: Users, accent: 'text-purple-300' },
    {
      label: 'Active Subscriptions',
      value: activeSubscriptions,
      icon: Activity,
      accent: 'text-emerald-400',
    },
    {
      label: 'Registered Devices',
      value: registeredDevices,
      icon: Smartphone,
      accent: 'text-zinc-200',
    },
  ];

  const maxTrend = Math.max(...WEEKLY_KEY_TREND.map((d) => d.generated));
  const totalServerUsers = Math.max(
    1,
    servers.reduce((acc, s) => acc + s.activeUsersDemo, 0)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Dashboard Statistics</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Overview of demonstration keys, subscriptions, regions, and activity.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigateSection('keys')}
          className="self-start sm:self-auto min-h-[40px] px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-zinc-800 text-xs font-medium text-zinc-200 transition-colors"
        >
          Manage All Keys
        </button>
      </div>

      {/* 8 Requested Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-2xl bg-[#101015] border border-zinc-800/90 p-4 sm:p-5"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs text-zinc-400 truncate">{stat.label}</span>
                <Icon className={`w-4 h-4 shrink-0 ${stat.accent}`} />
              </div>
              <p className="mt-3 font-display text-2xl sm:text-3xl font-bold text-white tabular-nums">
                {stat.value}
              </p>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Weekly Key Generation & Activation Bar/Line Chart */}
        <section className="lg:col-span-7 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Weekly Key Activity
              </h2>
              <p className="text-xs text-zinc-400">Generated vs activated keys (7-day demo series)</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-zinc-300">
                <span className="w-2.5 h-2.5 rounded-sm bg-purple-500" />
                Generated
              </span>
              <span className="flex items-center gap-1.5 text-zinc-400">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
                Active
              </span>
            </div>
          </div>

          <div className="h-52 flex items-end justify-between gap-2 sm:gap-4 pt-4 border-b border-zinc-800/80 pb-2">
            {WEEKLY_KEY_TREND.map((item) => {
              const genHeight = Math.round((item.generated / maxTrend) * 100);
              const actHeight = Math.round((item.active / maxTrend) * 100);
              return (
                <div key={item.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <div className="w-full max-w-[44px] flex items-end justify-center gap-1 h-40">
                    <div
                      title={`${item.day}: ${item.generated} generated`}
                      className="w-1/2 rounded-t-md bg-purple-600/85 hover:bg-purple-500 transition-colors"
                      style={{ height: `${genHeight}%` }}
                    />
                    <div
                      title={`${item.day}: ${item.active} active`}
                      className="w-1/2 rounded-t-md bg-emerald-500/80 hover:bg-emerald-400 transition-colors"
                      style={{ height: `${actHeight}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between gap-2 sm:gap-4 pt-2">
            {WEEKLY_KEY_TREND.map((item) => (
              <div key={item.day} className="flex-1 text-center">
                <p className="text-xs font-medium text-zinc-400">{item.day}</p>
                <p className="text-[11px] font-mono text-zinc-500 tabular-nums">{item.generated}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Regional Load Distribution */}
        <section className="lg:col-span-5 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="font-display text-base font-semibold text-white">
                Regional Distribution
              </h2>
              <p className="text-xs text-zinc-400">Simulated sessions across 5 regions</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateSection('servers')}
              className="text-xs font-medium text-purple-400 hover:text-purple-300"
            >
              Servers
            </button>
          </div>

          <div className="space-y-4">
            {servers.map((srv) => {
              const pct = Math.round((srv.activeUsersDemo / totalServerUsers) * 100);
              return (
                <div key={srv.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-200 font-medium flex items-center gap-2">
                      <span>{srv.flag}</span>
                      <span>{srv.name}</span>
                    </span>
                    <span className="font-mono text-zinc-400 tabular-nums">
                      {srv.activeUsersDemo} ({pct}%)
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-zinc-900 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-purple-600 to-violet-400"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Recent Generated Keys + Recent Activity */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
        {/* Recent Generated Keys */}
        <section className="xl:col-span-7 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
          <div className="flex items-center justify-between gap-4 mb-4">
            <h2 className="font-display text-base font-semibold text-white">
              Recent Generated Keys
            </h2>
            <button
              type="button"
              onClick={() => onNavigateSection('key-generator')}
              className="text-xs font-medium text-purple-400 hover:text-purple-300"
            >
              New Key
            </button>
          </div>

          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-500">
                  <th className="pb-2.5 font-medium">Product Key</th>
                  <th className="pb-2.5 font-medium">Distributor</th>
                  <th className="pb-2.5 font-medium">Plan</th>
                  <th className="pb-2.5 font-medium">Status</th>
                  <th className="pb-2.5 font-medium text-right">Expires</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {keys.slice(0, 5).map((k) => (
                  <tr key={k.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 font-mono text-zinc-200">{maskProductKey(k.key)}</td>
                    <td className="py-3 text-zinc-300">{k.distributorName}</td>
                    <td className="py-3 text-zinc-400 tabular-nums">{k.durationDays}d</td>
                    <td className="py-3 capitalize">
                      <span
                        className={
                          k.status === 'active'
                            ? 'text-emerald-400'
                            : k.status === 'suspended'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }
                      >
                        {k.status}
                      </span>
                    </td>
                    <td className="py-3 text-right text-zinc-400 tabular-nums">
                      {formatDateShort(k.expiresAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Management Cards */}
          <div className="md:hidden space-y-2.5">
            {keys.slice(0, 4).map((k) => (
              <div
                key={k.id}
                className="rounded-xl bg-[#07070A] border border-zinc-800/80 p-3.5 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <p className="font-mono text-xs text-zinc-100 truncate">
                    {maskProductKey(k.key)}
                  </p>
                  <p className="text-[11px] text-zinc-400 mt-0.5 truncate">
                    {k.distributorName} · {k.durationDays}d
                  </p>
                </div>
                <span
                  className={`text-xs font-medium capitalize shrink-0 ${
                    k.status === 'active'
                      ? 'text-emerald-400'
                      : k.status === 'suspended'
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {k.status}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Recent Activity */}
        <section className="xl:col-span-5 rounded-2xl bg-[#101015] border border-zinc-800/90 p-5">
          <div className="flex items-center justify-between gap-4 mb-4">
            <h2 className="font-display text-base font-semibold text-white">Recent Activity</h2>
            <button
              type="button"
              onClick={() => onNavigateSection('security-logs')}
              className="text-xs font-medium text-purple-400 hover:text-purple-300"
            >
              All Logs
            </button>
          </div>

          <div className="divide-y divide-zinc-800/60">
            {securityLogs.slice(0, 5).map((log) => (
              <div key={log.id} className="py-3 flex items-start justify-between gap-3 text-xs">
                <div className="min-w-0">
                  <p className="text-zinc-200 font-medium truncate">{log.event}</p>
                  <p className="text-zinc-500 mt-0.5 truncate">
                    {log.actor} · {log.target}
                  </p>
                </div>
                <span className="text-zinc-500 font-mono tabular-nums whitespace-nowrap shrink-0">
                  {formatDateTime(log.timestamp)}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
