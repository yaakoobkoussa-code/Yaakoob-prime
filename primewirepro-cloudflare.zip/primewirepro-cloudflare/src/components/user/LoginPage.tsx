import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  ClipboardPaste,
  KeyRound,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { formatProductKeyInput, PRODUCT_KEY_REGEX } from '../../utils/formatters';
import { BrandLogo } from '../common/BrandLogo';

interface LoginPageProps {
  onNavigateAdmin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigateAdmin }) => {
  const { loginUser, addToast, settings } = useAppState();
  const [keyInput, setKeyInput] = useState('');
  const [rememberDevice, setRememberDevice] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    setKeyInput(formatProductKeyInput(e.target.value));
  };

  const handlePaste = async () => {
    setErrorMsg(null);
    try {
      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        const formatted = formatProductKeyInput(text);
        setKeyInput(formatted);
        addToast({
          type: 'info',
          title: 'Key pasted from clipboard',
        });
        return;
      }
      addToast({
        type: 'warning',
        title: 'Clipboard is empty',
        description: 'Copy a product key first or type it into the input field.',
      });
    } catch {
      addToast({
        type: 'info',
        title: 'Clipboard access unavailable',
        description: 'Paste your product key directly into the field using Ctrl+V or long-press.',
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!PRODUCT_KEY_REGEX.test(keyInput)) {
      const msg = 'Enter a valid product key in PMWR-XXXX-XXXX-XXXX format.';
      setErrorMsg(msg);
      addToast({ type: 'error', title: 'Invalid format', description: msg });
      return;
    }

    setIsSubmitting(true);
    const result = await loginUser(keyInput, rememberDevice);
    setIsSubmitting(false);

    if (!result.ok && result.message) {
      setErrorMsg(result.message);
      addToast({
        type: 'error',
        title: 'Authentication failed',
        description: result.message,
      });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#080808] text-zinc-100 flex flex-col justify-between overflow-hidden px-4 py-6 pt-safe pb-safe">
      {/* Ambient Animated Background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[540px] h-[540px] rounded-full bg-purple-600/18 blur-[120px] animate-ambient" />
        <div className="absolute bottom-[-180px] right-[-100px] w-[420px] h-[420px] rounded-full bg-violet-700/12 blur-[110px]" />
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage:
              'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />
      </div>

      <div className="relative z-10 w-full max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BrandLogo size="sm" glow={false} />
          <span className="font-display text-sm font-semibold tracking-tight text-white">
            {settings.websiteTitle}
          </span>
        </div>
        <button
          type="button"
          onClick={onNavigateAdmin}
          className="min-h-[44px] px-3 text-xs font-medium text-zinc-400 hover:text-purple-300 transition-colors flex items-center gap-1.5"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Admin Console</span>
        </button>
      </div>

      <main className="relative z-10 w-full max-w-md mx-auto my-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-2xl bg-[#101014]/95 backdrop-blur-xl border border-white/10 p-6 sm:p-8 shadow-2xl shadow-black/70"
        >
          <div className="flex flex-col items-center text-center">
            <BrandLogo size="xl" glow />
            <h1 className="mt-5 font-display text-2xl font-bold tracking-tight text-white text-balance">
              PRIME WIRE PRO
            </h1>
            <p className="mt-1.5 text-sm text-zinc-400">
              Sign in with your product key to access configuration profiles.
            </p>
          </div>

          {settings.maintenanceMode && (
            <div className="mt-5 rounded-xl bg-amber-500/10 border border-amber-500/30 px-4 py-3 text-xs text-amber-200 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>Maintenance mode is enabled in Admin settings. Client sign-in is paused.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label
                  htmlFor="product-key-input"
                  className="text-xs font-medium text-zinc-300"
                >
                  Product Key
                </label>
                <span className="text-[11px] font-mono text-zinc-500">PMWR-XXXX-XXXX-XXXX</span>
              </div>

              <div className="relative flex items-center">
                <KeyRound className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                <input
                  id="product-key-input"
                  type="text"
                  value={keyInput}
                  onChange={handleKeyChange}
                  placeholder="PMWR-XXXX-XXXX-XXXX"
                  autoCapitalize="characters"
                  autoCorrect="off"
                  spellCheck={false}
                  maxLength={19}
                  className="w-full min-h-[48px] pl-10 pr-28 rounded-xl bg-[#080808] border border-white/12 text-[13px] sm:text-sm font-mono tracking-wider text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/25 transition-all"
                />
                <button
                  type="button"
                  onClick={handlePaste}
                  className="absolute right-1.5 min-h-[38px] px-3 rounded-lg bg-white/5 hover:bg-purple-500/15 border border-white/10 hover:border-purple-500/40 text-xs font-medium text-zinc-200 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                >
                  <ClipboardPaste className="w-3.5 h-3.5 text-purple-400" />
                  <span>Paste Key</span>
                </button>
              </div>
            </div>

            {errorMsg && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                role="alert"
                className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 flex items-start gap-2.5 text-xs text-rose-200"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </motion.div>
            )}

            <label className="flex items-center justify-between gap-3 cursor-pointer select-none min-h-[44px] px-1">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={rememberDevice}
                  onClick={() => setRememberDevice((v) => !v)}
                  className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                    rememberDevice
                      ? 'bg-purple-600 border-purple-400 text-white'
                      : 'bg-[#080808] border-white/20 text-transparent'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
                <span className="text-sm text-zinc-300">Remember this device</span>
              </div>
              <span className="text-xs text-zinc-500">Phase 1 Demo</span>
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full min-h-[48px] rounded-xl bg-purple-600 hover:bg-purple-500 active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed text-sm font-semibold text-white shadow-[0_0_24px_rgba(147,51,234,0.38)] flex items-center justify-center gap-2 transition-all"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying key...</span>
                </>
              ) : (
                <>
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </motion.div>
      </main>

      <footer className="relative z-10 w-full max-w-6xl mx-auto text-center text-xs text-zinc-500">
        <span>PRIME WIRE PRO</span>
        <span className="mx-2" aria-hidden="true">·</span>
        <span>Phase 1 Frontend Preview (Simulated Authentication)</span>
      </footer>
    </div>
  );
};
