import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { OFFICIAL_LOGO_PATH } from '../../data/demoData';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  glow?: boolean;
  className?: string;
}

const SIZE_MAP = {
  sm: 'w-8 h-8 rounded-lg',
  md: 'w-10 h-10 rounded-xl',
  lg: 'w-16 h-16 rounded-2xl',
  xl: 'w-20 h-20 rounded-2xl',
};

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  glow = true,
  className = '',
}) => {
  const [failed, setFailed] = useState(false);

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 overflow-hidden bg-[#121218] border border-purple-500/30 ${
        glow ? 'shadow-[0_0_24px_rgba(168,85,247,0.28)]' : ''
      } ${SIZE_MAP[size]} ${className}`}
    >
      {!failed ? (
        <img
          src={OFFICIAL_LOGO_PATH}
          alt="PRIME WIRE PRO logo"
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="w-full h-full object-cover"
        />
      ) : (
        <Shield className="w-1/2 h-1/2 text-purple-400" />
      )}
    </div>
  );
};
