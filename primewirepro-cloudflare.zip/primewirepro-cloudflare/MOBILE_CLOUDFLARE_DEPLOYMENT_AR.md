# دليل نشر PRIME WIRE PRO على Cloudflare من الهاتف خطوة بخطوة

هذا الدليل مخصّص للنشر الكامل على خطة **Cloudflare المجانية** مباشرةً من متصفح الهاتف (Android أو iPhone) بدون الحاجة إلى جهاز كمبيوتر، ويشمل:
- **قاعدة بيانات Cloudflare D1** (`workers/migrations/0001_initial.sql`)
- **الخادم الخلفي Cloudflare Workers API** (`workers/api/src/` + `workers/wrangler.toml`)
- **الموقع العام Public Website** (`primewirepro.pages.dev` — يُبنى من `index.html` و`src/public/`)
- **لوحة الإدارة المنفصلة Admin Dashboard** (`primewirepro-dashboard.pages.dev` — تُبنى من `admin.html` و`src/admin/`)

---

## المحتويات داخل ملف ZIP

- `index.html` و`src/public/` ← واجهة المستخدم العامة (تُسقط في `dist/` عند البناء عبر `npm run build:public`)
- `admin.html` و`src/admin/` ← لوحة الإدارة المستقلة (تُسقط في `dist-admin/` عند البناء عبر `npm run build:admin`)
- `src/shared/` و`src/components/common/` و`src/utils/` ← المكونات المشتركة (بدون أي أسرار أو روابط وهمية)
- `workers/api/src/` ← كود الخادم الخلفي Cloudflare Worker
- `workers/migrations/0001_initial.sql` ← بنية قاعدة بيانات Cloudflare D1 كاملة (15 جدولاً + 5 سيرفرات + ميزتان + 10 خانات اشتراك فارغة + أدوار الصلاحيات)
- `workers/wrangler.toml` ← ملف إعدادات Worker وربط D1 ونطاقات CORS
- `.env.example` ← قالب المتغيرات البيئية (خالي من أي أسرار حقيقية)
- `prebuilt/public-pages/` و`prebuilt/admin-pages/` ← مخرجات بناء تم التحقق منها محلياً

> **ملاحظة أمنية:** ملف ZIP لا يحتوي على `.env` أو `.local-data/` أو أي مفاتيح سرية أو روابط اشتراك وهمية.

---

## التحضير من الهاتف (5 دقائق)

1. حمّل ملف **`primewirepro-cloudflare.zip`** على هاتفك وفك ضغطه (باستخدام تطبيق الملفات في iPhone أو ZArchiver / Files في Android).
2. أنشئ حساباً مجانياً على **GitHub** (إذا لم يكن لديك) وأنشئ مستودعاً خاصاً (**Private Repository**) باسم مثلاً `primewirepro`.
3. ارفع محتويات المشروع المفكوكة إلى مستودع GitHub (من متصفح الهاتف عبر GitHub Web -> *uploading an existing file*، أو عبر تطبيق Git / Termux).
4. تأكد أن لديك حساباً مجانياً على **dash.cloudflare.com**.

---

## الخطوة 1: إنشاء قاعدة بيانات Cloudflare D1 وتطبيق الجداول

من متصفح الهاتف افتح [dash.cloudflare.com](https://dash.cloudflare.com):

1. من القائمة الجانبية افتح **Storage & Databases** → **D1 SQL Database**.
2. اضغط **Create** واكتب الاسم: `primewirepro-db` ثم **Create**.
3. بعد الإنشاء، انسخ قيمة **Database ID** الظاهرة في صفحة قاعدة البيانات.
4. افتح تبويب **Console** داخل `primewirepro-db`:
   - افتح ملف `workers/migrations/0001_initial.sql` على هاتفك وانسخ محتواه بالكامل.
   - الصقه في Console واضغط **Execute** لتنفيذ جميع الجداول والبذور الأولية.
5. افتح ملف `workers/wrangler.toml` في مستودعك على GitHub، واضغط تعديل (Edit) واستبدل:
   ```toml
   database_id = "REPLACE_WITH_YOUR_D1_DATABASE_ID"
   ```
   بالمعرّف الحقيقي لقاعدة البيانات التي أنشأتها، ثم احفظ (Commit).

---

## الخطوة 2: نشر Backend (Cloudflare Worker) وإضافة الأسرار

1. من Cloudflare Dashboard افتح **Workers & Pages** → **Create** → **Import a repository**.
2. اختر مستودعك `primewirepro` على GitHub.
3. في إعدادات النشر (Build / Deploy Settings):
   - **Root directory (المجلد الجذري):** `workers`
   - **Deploy command:** `npx wrangler deploy`
4. اضغط **Save and Deploy**.
5. بعد النشر، افتح صفحة الـ Worker (`primewirepro-api`) ثم اذهب إلى **Settings** → **Variables and Secrets** وأضف متغيرين من نوع **Secret** (Encrypted):
   - `SESSION_SECRET`: قيمة عشوائية طويلة ومختلفة (64 محرفاً — يمكنك نسخ القيمة التي وُلّدت لك في `.env` محلياً أو توليد قيمة جديدة من 64 حرفاً).
   - `BOOTSTRAP_SETUP_SECRET`: قيمة عشوائية أخرى مختلفة كلياً عن الأولى (تُستخدم مرة واحدة فقط لإنشاء حساب `SUPER_ADMIN` الأول).
6. تأكد في نفس الصفحة تحت **Variables** من وجود:
   - `PUBLIC_ORIGIN` = `https://primewirepro.pages.dev` (أو نطاقك البديل في الخطوة 3)
   - `ADMIN_ORIGIN` = `https://primewirepro-dashboard.pages.dev` (أو نطاقك البديل في الخطوة 4)
   - `ALLOW_LOCAL_DEV_ORIGINS` = `false`
7. تحت **Bindings** تأكد أن ربط **D1 Database** باسم متغير `DB` موصول بـ `primewirepro-db`.
8. انسخ رابط الـ Worker الحقيقي من أعلى الصفحة، مثال شكله:
   `https://primewirepro-api.<your-subdomain>.workers.dev`
   واختبره بفتحه في متصفح الهاتف مع `/api/health` — يجب أن يرجع `{"ok":true,...}`.

---

## الخطوة 3: نشر الموقع العام (Public Website) على Cloudflare Pages

1. من Cloudflare Dashboard افتح **Workers & Pages** → **Create** → تبويب **Pages** → **Connect to Git**.
2. اختر نفس مستودع GitHub (`primewirepro`).
3. في إعدادات المشروع:
   - **Project name:** `primewirepro` *(إذا كان محجوزاً مسبقاً، اختر اسماً متاحاً مثل `primewirepro-portal`)*
   - **Production branch:** `main`
   - **Build command:** `npm run build:public`
   - **Build output directory:** `dist`
4. قبل الضغط على Deploy، افتح **Environment variables (for production)** وأضف:
   - الاسم: `VITE_API_BASE_URL`
   - القيمة: **رابط Cloudflare Worker الحقيقي من الخطوة 2** (بدون `/` في النهاية).
5. اضغط **Save and Deploy**.
6. ستحصل على رابط الموقع العام: `https://primewirepro.pages.dev` (أو الاسم البديل الذي اخترته).

---

## الخطوة 4: نشر لوحة الإدارة المنفصلة (Admin Dashboard) على Cloudflare Pages

1. ارجع إلى **Workers & Pages** → **Create** → تبويب **Pages** → **Connect to Git**.
2. اختر نفس مستودع GitHub (`primewirepro`).
3. في إعدادات المشروع الثاني:
   - **Project name:** `primewirepro-dashboard` *(إذا كان محجوزاً مسبقاً، اختر اسماً متاحاً مثل `primewirepro-console-adm`)*
   - **Production branch:** `main`
   - **Build command:** `npm run build:admin`
   - **Build output directory:** `dist-admin`
4. أضف نفس المتغير في **Environment variables (for production)**:
   - الاسم: `VITE_API_BASE_URL`
   - القيمة: **نفس رابط Cloudflare Worker الحقيقي من الخطوة 2**.
5. اضغط **Save and Deploy**.

> **مهم جداً (CORS):** إذا اضطررت لاستخدام اسم نطاق `.pages.dev` مختلف عن `primewirepro.pages.dev` أو `primewirepro-dashboard.pages.dev`، حدّث `PUBLIC_ORIGIN` و`ADMIN_ORIGIN` في إعدادات Worker على Cloudflare Dashboard (أو في `workers/wrangler.toml`) لتطابق الروابط الفعلية 100%.

---

## الخطوة 5: إنشاء حساب المدير الأول (`primeadmin`) وإضافة روابط Happ

1. افتح رابط لوحة الإدارة (`https://primewirepro-dashboard.pages.dev`) من متصفح الهاتف.
2. لأن قاعدة البيانات جديدة ولا تحتوي على أي مدير، ستظهر شاشة **Initial SUPER ADMIN Setup** تلقائياً:
   - **Setup Secret:** أدخل قيمة `BOOTSTRAP_SETUP_SECRET` التي أضفتها في الخطوة 2.
   - **Username:** `primeadmin`
   - **Email:** بريدك الإلكتروني الحقيقي.
   - **Password:** كلمة مرور قوية من اختيارك (10 أحرف على الأقل).
3. اضغط إنشاء الحساب، ثم سجّل الدخول بحساب `primeadmin` — وبعدها يُغلق مسار التهيئة تلقائياً إلى الأبد.
4. من قائمة الإدارة افتح **Subscription URLs (10)** وأضف روابط اشتراك **Happ** الحقيقية الخاصة بك وفعّلها حسب السيرفر والميزة.
5. من **Key Management** أنشئ مفاتيح `PMWR-XXXX-XXXX-XXXX` ووزّعها، أو استخدم **Universal Codes** للأكواد المشتركة.

---

## حدود خطة Cloudflare المجانية (Free Plan)

- **Cloudflare Pages:** باندويث غير محدود، 500 بناء شهرياً، شهادات HTTPS تلقائية.
- **Cloudflare Workers:** 100,000 طلب يومياً مجاناً، 10ms وقت معالجة CPU للطلب.
- **Cloudflare D1:** تخزين 5GB، و5 ملايين قراءة صف/يوم، و100 ألف كتابة صف/يوم.
