import React, { useState } from 'react';
import { motion } from 'motion/react';
import { AlertCircle, KeyRound, Loader2, Lock, Mail, ShieldCheck, UserCheck } from 'lucide-react';
import { BrandLogo } from '../../components/common/BrandLogo';
import { useAdminAuth } from '../hooks/useAdminAuth';

export const AdminLoginPage: React.FC = () => {
  const { needsBootstrap, login, bootstrapSuperAdmin } = useAdminAuth();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');

  // Initial SUPER ADMIN bootstrap fields (only shown when DB has 0 admins)
  const [setupSecret, setSetupSecret] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [bootPassword, setBootPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await login(identifier, password);
    setLoading(false);
    if (!res.ok && res.error) setError(res.error);
  };

  const handleBootstrap = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await bootstrapSuperAdmin({
      setupSecret,
      username,
      email,
      password: bootPassword,
    });
    setLoading(false);
    if (!res.ok && res.error) setError(res.error);
  };

  return (
    <div className="min-h-screen bg-[#07070A] text-zinc-100 flex flex-col justify-between px-4 py-6 pt-safe pb-safe">
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BrandLogo size="sm" glow={false} />
          <span className="font-display text-sm font-bold text-white">PRIME WIRE PRO</span>
        </div>
        <span className="text-xs font-mono text-zinc-500">Administration Dashboard</span>
      </div>

      <main className="w-full max-w-md mx-auto my-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="rounded-2xl bg-[#101015] border border-zinc-800 p-6 sm:p-8 shadow-2xl shadow-black/80"
        >
          <div className="flex items-center gap-3.5">
            <BrandLogo size="md" glow={false} />
            <div>
              <div className="flex items-center gap-1.5 text-xs font-medium text-purple-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{needsBootstrap ? 'Initial Setup' : 'Restricted Access'}</span>
              </div>
              <h1 className="font-display text-xl font-bold text-white">
                {needsBootstrap ? 'Create SUPER ADMIN' : 'Admin Sign In'}
              </h1>
            </div>
          </div>

          {needsBootstrap ? (
            <form onSubmit={handleBootstrap} className="mt-5 space-y-4">
              <p className="text-xs text-zinc-400 leading-relaxed">
                No administrator exists in Cloudflare D1 yet. Provide your server{' '}
                <code className="font-mono text-zinc-200">BOOTSTRAP_SETUP_SECRET</code> to create
                the initial SUPER ADMIN account.
              </p>

              <div>
                <label htmlFor="boot-secret" className="block text-xs font-medium text-zinc-300 mb-1">
                  Bootstrap Setup Secret
                </label>
                <div className="relative flex items-center">
                  <KeyRound className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                  <input
                    id="boot-secret"
                    type="password"
                    required
                    value={setupSecret}
                    onChange={(e) => setSetupSecret(e.target.value)}
                    placeholder="Enter server bootstrap secret"
                    className="w-full min-h-[44px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="boot-user" className="block text-xs font-medium text-zinc-300 mb-1">
                  Username
                </label>
                <div className="relative flex items-center">
                  <UserCheck className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                  <input
                    id="boot-user"
                    type="text"
                    required
                    minLength={3}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="superadmin"
                    className="w-full min-h-[44px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="boot-email" className="block text-xs font-medium text-zinc-300 mb-1">
                  Email
                </label>
                <div className="relative flex items-center">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                  <input
                    id="boot-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@example.com"
                    className="w-full min-h-[44px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="boot-pass" className="block text-xs font-medium text-zinc-300 mb-1">
                  Password (min 10 characters)
                </label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                  <input
                    id="boot-pass"
                    type="password"
                    required
                    minLength={10}
                    value={bootPassword}
                    onChange={(e) => setBootPassword(e.target.value)}
                    placeholder="Strong passphrase"
                    className="w-full min-h-[44px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {error && (
                <div
                  role="alert"
                  className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 text-xs text-rose-200 flex items-start gap-2"
                >
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full min-h-[48px] rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-60 text-sm font-semibold text-white flex items-center justify-center gap-2 transition-colors"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                <span>Initialize SUPER ADMIN</span>
              </button>
            </form>
          ) : (
            <form onSubmit={handleLogin} className="mt-5 space-y-4">
              <p className="text-xs text-zinc-400">
                Sign in with your administrator email or username and password.
              </p>

              <div>
                <label htmlFor="adm-id" className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Email or Username
                </label>
                <div className="relative flex items-center">
                  <UserCheck className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                  <input
                    id="adm-id"
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="superadmin"
                    className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="adm-pw" className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Password
                </label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 pointer-events-none" />
                  <input
                    id="adm-pw"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full min-h-[46px] pl-10 pr-3 rounded-xl bg-[#07070A] border border-zinc-800 text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {error && (
                <div
                  role="alert"
                  className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-3.5 py-2.5 text-xs text-rose-200 flex items-start gap-2"
                >
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full min-h-[48px] rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-60 text-sm font-semibold text-white flex items-center justify-center gap-2 transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Authenticating...</span>
                  </>
                ) : (
                  <span>Sign In</span>
                )}
              </button>
            </form>
          )}
        </motion.div>
      </main>

      <footer className="w-full max-w-5xl mx-auto text-center text-xs text-zinc-600">
        PRIME WIRE PRO Administration · Cloudflare Workers & D1
      </footer>
    </div>
  );
};
