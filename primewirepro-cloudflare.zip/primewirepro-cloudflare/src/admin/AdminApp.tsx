import React, { useState } from 'react';
import { LoadingScreen } from '../components/common/LoadingScreen';
import { ToastProvider } from '../shared/ToastProvider';
import { AdminAuthProvider, useAdminAuth } from './hooks/useAdminAuth';
import { AdminLoginPage } from './components/AdminLoginPage';
import { AdminManagementPage } from './components/AdminManagementPage';
import { AdminOverviewPage } from './components/AdminOverviewPage';
import { AdminSectionId, AdminShell } from './components/AdminShell';
import { DeviceManagementPage } from './components/DeviceManagementPage';
import { FeaturePermissionsPage } from './components/FeaturePermissionsPage';
import { KeyManagementPage } from './components/KeyManagementPage';
import { SecurityLogsPage } from './components/SecurityLogsPage';
import { ServerManagementPage } from './components/ServerManagementPage';
import { SubscriptionUrlPage } from './components/SubscriptionUrlPage';
import { UniversalCodePage } from './components/UniversalCodePage';
import { WebsiteSettingsPage } from './components/WebsiteSettingsPage';

const AdminRouter: React.FC = () => {
  const { booting, admin, can } = useAdminAuth();
  const [activeSection, setActiveSection] = useState<AdminSectionId>('overview');

  if (booting) {
    return <LoadingScreen message="Authenticating admin session..." />;
  }

  if (!admin) {
    return <AdminLoginPage />;
  }

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return <AdminOverviewPage onNavigate={setActiveSection} />;
      case 'keys':
        return can('keys.view') ? <KeyManagementPage /> : <AdminOverviewPage onNavigate={setActiveSection} />;
      case 'universal':
        return can('universal.view') ? <UniversalCodePage /> : <AdminOverviewPage onNavigate={setActiveSection} />;
      case 'devices':
        return can('devices.view') ? <DeviceManagementPage /> : <AdminOverviewPage onNavigate={setActiveSection} />;
      case 'admins':
        return can('admins.manage') ? <AdminManagementPage /> : <AdminOverviewPage onNavigate={setActiveSection} />;
      case 'servers':
        return (
          <ServerManagementPage
            onOpenUrls={can('urls.manage') ? () => setActiveSection('urls') : undefined}
          />
        );
      case 'urls':
        return can('urls.manage') ? <SubscriptionUrlPage /> : <AdminOverviewPage onNavigate={setActiveSection} />;
      case 'features':
        return <FeaturePermissionsPage />;
      case 'settings':
        return <WebsiteSettingsPage />;
      case 'logs':
        return can('logs.view') ? <SecurityLogsPage /> : <AdminOverviewPage onNavigate={setActiveSection} />;
      default:
        return <AdminOverviewPage onNavigate={setActiveSection} />;
    }
  };

  return (
    <AdminShell activeSection={activeSection} onSelectSection={setActiveSection}>
      {renderSection()}
    </AdminShell>
  );
};

export const AdminApp: React.FC = () => {
  return (
    <ToastProvider>
      <AdminAuthProvider>
        <AdminRouter />
      </AdminAuthProvider>
    </ToastProvider>
  );
};

export default AdminApp;
