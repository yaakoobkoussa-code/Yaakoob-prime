import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  ApiError,
  apiRequest,
  getStoredUserToken,
  setStoredUserTokens,
} from '../../shared/api';
import { useToast } from '../../shared/ToastProvider';
import {
  FeatureId,
  PublicStatusResponse,
  ServerId,
  UserMeResponse,
} from '../../shared/types';

interface PublicAuthContextValue {
  booting: boolean;
  publicStatus: PublicStatusResponse | null;
  userData: UserMeResponse | null;
  login: (code: string, rememberDevice: boolean) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  selectServer: (serverId: ServerId) => Promise<void>;
  toggleFeature: (featureId: FeatureId) => Promise<void>;
}

const PublicAuthContext = createContext<PublicAuthContextValue | null>(null);

export const PublicAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { addToast } = useToast();
  const [booting, setBooting] = useState(true);
  const [publicStatus, setPublicStatus] = useState<PublicStatusResponse | null>(null);
  const [userData, setUserData] = useState<UserMeResponse | null>(null);

  const fetchStatusAndUser = useCallback(async () => {
    try {
      const status = await apiRequest<PublicStatusResponse>('/api/public/status');
      setPublicStatus(status);
      if (status.websiteTitle) {
        document.title = status.websiteTitle;
      }
      if (status.maintenanceMode) {
        setUserData(null);
        return;
      }
    } catch {
      // Keep previous status if transient error
    }

    try {
      const me = await apiRequest<UserMeResponse>('/api/user/me', { scope: 'user' });
      setUserData(me);
    } catch (err) {
      setUserData(null);
      if (err instanceof ApiError && err.code === 'MAINTENANCE_MODE') {
        setPublicStatus((prev) => (prev ? { ...prev, maintenanceMode: true } : prev));
      }
      if (err instanceof ApiError && err.status === 401 && getStoredUserToken()) {
        setStoredUserTokens(null);
      }
    }
  }, []);

  useEffect(() => {
    (async () => {
      await fetchStatusAndUser();
      setBooting(false);
    })();
  }, [fetchStatusAndUser]);

  // Periodically check backend session validity, expiration, and maintenance mode
  useEffect(() => {
    const timer = window.setInterval(() => {
      fetchStatusAndUser();
    }, 30_000);
    return () => window.clearInterval(timer);
  }, [fetchStatusAndUser]);

  const login = useCallback(
    async (code: string, rememberDevice: boolean) => {
      try {
        const res = await apiRequest<{
          ok: boolean;
          sessionToken: string;
          deviceToken: string;
          authType: 'product_key' | 'universal_code';
        }>('/api/auth/login', {
          method: 'POST',
          body: { code, rememberDevice },
        });
        setStoredUserTokens(res.sessionToken, res.deviceToken);
        await fetchStatusAndUser();
        addToast({
          type: 'success',
          title: 'Access granted',
          description:
            res.authType === 'product_key'
              ? 'Product key verified and bound to this device.'
              : 'Universal public code verified.',
        });
        return { ok: true };
      } catch (err) {
        const msg = err instanceof ApiError ? err.message : 'Unable to reach server.';
        if (err instanceof ApiError && err.code === 'MAINTENANCE_MODE') {
          await fetchStatusAndUser();
        }
        return { ok: false, error: msg };
      }
    },
    [fetchStatusAndUser, addToast]
  );

  const logout = useCallback(async () => {
    try {
      await apiRequest('/api/auth/logout', { method: 'POST', scope: 'user' });
    } catch {
      // Clear local session regardless
    }
    setStoredUserTokens(null);
    setUserData(null);
    addToast({
      type: 'info',
      title: 'Signed out',
      description: 'Session closed. Device binding remains intact for product keys.',
    });
  }, [addToast]);

  const selectServer = useCallback(
    async (serverId: ServerId) => {
      try {
        await apiRequest('/api/user/preferences', {
          method: 'PATCH',
          scope: 'user',
          body: { selectedServerId: serverId },
        });
        await fetchStatusAndUser();
        addToast({
          type: 'success',
          title: 'Server region updated',
        });
      } catch (err) {
        addToast({
          type: 'error',
          title: 'Server selection failed',
          description: err instanceof ApiError ? err.message : 'Server unavailable.',
        });
      }
    },
    [fetchStatusAndUser, addToast]
  );

  const toggleFeature = useCallback(
    async (featureId: FeatureId) => {
      if (!userData) return;
      const nextFeature = userData.session.activeFeatureId === featureId ? null : featureId;
      try {
        await apiRequest('/api/user/preferences', {
          method: 'PATCH',
          scope: 'user',
          body: { activeFeatureId: nextFeature },
        });
        await fetchStatusAndUser();
        const featTitle = userData.features.find((f) => f.id === featureId)?.title ?? featureId;
        addToast({
          type: nextFeature ? 'success' : 'info',
          title: nextFeature ? `${featTitle} activated` : `${featTitle} deactivated`,
          description: nextFeature ? 'Only one feature can remain active at a time.' : undefined,
        });
      } catch (err) {
        addToast({
          type: 'error',
          title: 'Feature update failed',
          description: err instanceof ApiError ? err.message : 'Unable to update feature.',
        });
      }
    },
    [userData, fetchStatusAndUser, addToast]
  );

  return (
    <PublicAuthContext.Provider
      value={{
        booting,
        publicStatus,
        userData,
        login,
        logout,
        refreshUser: fetchStatusAndUser,
        selectServer,
        toggleFeature,
      }}
    >
      {children}
    </PublicAuthContext.Provider>
  );
};

export function usePublicAuth() {
  const ctx = useContext(PublicAuthContext);
  if (!ctx) throw new Error('usePublicAuth must be used inside PublicAuthProvider');
  return ctx;
}
