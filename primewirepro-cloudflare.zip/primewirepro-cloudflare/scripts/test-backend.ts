import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { LocalD1Database } from '../workers/api/src/localD1';
import { handleApiRequest } from '../workers/api/src/router';
import { WorkerEnv } from '../workers/api/src/types';

const MIGRATIONS_DIR = path.resolve(process.cwd(), 'workers/migrations');

async function createTestHarness() {
  const db = new LocalD1Database(':memory:');
  db.runMigrations(MIGRATIONS_DIR);

  const env: WorkerEnv = {
    DB: db,
    SESSION_SECRET: 'test-session-secret-32-chars-minimum-1234',
    BOOTSTRAP_SETUP_SECRET: 'test-bootstrap-secret-1234',
    PUBLIC_ORIGIN: 'https://primewirepro.pages.dev',
    ADMIN_ORIGIN: 'https://primewirepro-dashboard.pages.dev',
    ALLOW_LOCAL_DEV_ORIGINS: 'false',
  };

  async function callApi(
    pathname: string,
    opts: {
      method?: string;
      body?: unknown;
      origin?: string;
      bearer?: string;
      deviceToken?: string;
      bootstrapSecret?: string;
      ip?: string;
      userAgent?: string;
    } = {}
  ) {
    const headers = new Headers();
    if (opts.body !== undefined) headers.set('Content-Type', 'application/json');
    if (opts.origin) headers.set('Origin', opts.origin);
    if (opts.bearer) headers.set('Authorization', `Bearer ${opts.bearer}`);
    if (opts.deviceToken) headers.set('X-Device-Token', opts.deviceToken);
    if (opts.bootstrapSecret) headers.set('X-Bootstrap-Secret', opts.bootstrapSecret);
    headers.set('CF-Connecting-IP', opts.ip ?? '203.0.113.10');
    headers.set('User-Agent', opts.userAgent ?? 'Android Device Chrome/130');

    const req = new Request(`https://api.example.workers.dev${pathname}`, {
      method: opts.method ?? 'GET',
      headers,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
    const res = await handleApiRequest(req, env);
    const json = (await res.json().catch(() => ({}))) as Record<string, any>;
    return { status: res.status, json, headers: res.headers };
  }

  return { db, env, callApi };
}

async function runTests() {
  const { db, callApi } = await createTestHarness();
  let passed = 0;

  const test = async (name: string, fn: () => Promise<void>) => {
    await fn();
    passed += 1;
    console.log(`PASS: ${name}`);
  };

  // 1. Bootstrap & CSRF
  await test('Bootstrap status starts true and rejects wrong setup secret', async () => {
    const st = await callApi('/api/admin/bootstrap-status');
    assert.equal(st.status, 200);
    assert.equal(st.json.needsBootstrap, true);

    const bad = await callApi('/api/admin/bootstrap', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        setupSecret: 'wrong-secret',
        username: 'founder',
        email: 'founder@primewire.test',
        password: 'StrongPassword#2025',
      },
    });
    assert.equal(bad.status, 403);
  });

  await test('CSRF rejects untrusted origin on state-changing requests', async () => {
    const res = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://evil-phishing.example.com',
      body: { code: 'PMWR-AAAA-BBBB-CCCC' },
    });
    assert.equal(res.status, 403);
  });

  await test('Initial SUPER_ADMIN bootstrap succeeds once and locks afterwards', async () => {
    const ok = await callApi('/api/admin/bootstrap', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        setupSecret: 'test-bootstrap-secret-1234',
        username: 'founder',
        email: 'founder@primewire.test',
        password: 'StrongPassword#2025',
      },
    });
    assert.equal(ok.status, 201);
    assert.equal(ok.json.roleId, 'SUPER_ADMIN');

    const second = await callApi('/api/admin/bootstrap', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        setupSecret: 'test-bootstrap-secret-1234',
        username: 'hacker',
        email: 'hacker@primewire.test',
        password: 'StrongPassword#2025',
      },
    });
    assert.equal(second.status, 403);

    const st = await callApi('/api/admin/bootstrap-status');
    assert.equal(st.json.needsBootstrap, false);
  });

  // 2. Admin login + RBAC + Rate Limiting
  let superToken = '';
  let viewerToken = '';

  await test('Admin login validates PBKDF2 password and issues token', async () => {
    const wrong = await callApi('/api/admin/login', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      ip: '198.51.100.1',
      body: { identifier: 'founder', password: 'WrongPassword123!' },
    });
    assert.equal(wrong.status, 401);

    const ok = await callApi('/api/admin/login', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      ip: '198.51.100.1',
      body: { identifier: 'founder@primewire.test', password: 'StrongPassword#2025' },
    });
    assert.equal(ok.status, 200);
    assert.ok(ok.json.adminToken);
    superToken = ok.json.adminToken;
  });

  await test('RBAC enforces VIEW_ONLY vs SUPER_ADMIN permissions', async () => {
    const createdViewer = await callApi('/api/admin/admins', {
      method: 'POST',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        username: 'auditor',
        email: 'auditor@primewire.test',
        password: 'ViewerPassword#2025',
        roleId: 'VIEW_ONLY',
      },
    });
    assert.equal(createdViewer.status, 201);

    const vLogin = await callApi('/api/admin/login', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      ip: '198.51.100.2',
      body: { identifier: 'auditor', password: 'ViewerPassword#2025' },
    });
    assert.equal(vLogin.status, 200);
    viewerToken = vLogin.json.adminToken;

    // VIEW_ONLY cannot create keys or admins
    const tryKey = await callApi('/api/admin/keys', {
      method: 'POST',
      bearer: viewerToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { count: 1 },
    });
    assert.equal(tryKey.status, 403);

    const tryAdmin = await callApi('/api/admin/admins', {
      method: 'POST',
      bearer: viewerToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        username: 'escalate',
        email: 'escalate@primewire.test',
        password: 'Password#2025',
        roleId: 'SUPER_ADMIN',
      },
    });
    assert.equal(tryAdmin.status, 403);

    // VIEW_ONLY can view logs
    const logs = await callApi('/api/admin/logs', { bearer: viewerToken });
    assert.equal(logs.status, 200);
    assert.ok(Array.isArray(logs.json.logs));
  });

  await test('Admin brute-force login triggers 429 rate limit', async () => {
    for (let i = 0; i < 8; i++) {
      const res = await callApi('/api/admin/login', {
        method: 'POST',
        origin: 'https://primewirepro-dashboard.pages.dev',
        ip: '198.51.100.99',
        body: { identifier: 'founder', password: 'BadPassword!' },
      });
      assert.equal(res.status, 401);
    }
    const limited = await callApi('/api/admin/login', {
      method: 'POST',
      origin: 'https://primewirepro-dashboard.pages.dev',
      ip: '198.51.100.99',
      body: { identifier: 'founder', password: 'BadPassword!' },
    });
    assert.equal(limited.status, 429);
  });

  // 3. Subscription URLs initially empty (10) & SSRF validation
  await test('Database seeds 5 servers, 2 features (no skin), and 10 empty subscription URLs', async () => {
    const serversRes = await callApi('/api/admin/servers', { bearer: superToken });
    assert.equal(serversRes.status, 200);
    assert.equal(serversRes.json.servers.length, 5);

    const featRes = await callApi('/api/admin/features', { bearer: superToken });
    assert.equal(featRes.status, 200);
    assert.equal(featRes.json.features.length, 2);
    assert.ok(!featRes.json.features.some((f: any) => String(f.id).includes('skin')));

    const urlsRes = await callApi('/api/admin/subscription-urls', { bearer: superToken });
    assert.equal(urlsRes.status, 200);
    assert.equal(urlsRes.json.urls.length, 10);
    for (const u of urlsRes.json.urls) {
      assert.equal(u.url, '');
      assert.equal(u.enabled, 0);
    }
  });

  await test('Subscription URL rejects SSRF private/loopback URLs', async () => {
    const bad = await callApi('/api/admin/subscription-urls/singapore__aim_point', {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { url: 'http://127.0.0.1:8080/secret', enabled: true },
    });
    assert.equal(bad.status, 400);
  });

  // 4. Product Key Permanent 1-Device Binding & Unbind
  let keyId = '';
  let keyCode = '';
  let deviceAToken = '';
  let userASessionToken = '';

  await test('Product key binds permanently to Device A, blocks Device B, survives logout, and unlocks only after admin unbind', async () => {
    const created = await callApi('/api/admin/keys', {
      method: 'POST',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        count: 1,
        durationSeconds: 86400,
        notes: 'Permanent bind test',
      },
    });
    assert.equal(created.status, 201);
    keyId = created.json.created[0].id;
    keyCode = created.json.created[0].key_code;

    // Device A activates key
    const loginA = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      body: { code: keyCode, rememberDevice: true },
    });
    assert.equal(loginA.status, 200);
    deviceAToken = loginA.json.deviceToken;
    userASessionToken = loginA.json.sessionToken;
    assert.ok(deviceAToken && userASessionToken);

    // Device B (different/no device token) is rejected with 403 DEVICE_MISMATCH
    const loginB = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      userAgent: 'iPhone iOS Safari',
      body: { code: keyCode, rememberDevice: true },
    });
    assert.equal(loginB.status, 403);
    assert.equal(loginB.json.code, 'DEVICE_MISMATCH');

    // Device A logs out — binding MUST persist
    const logoutA = await callApi('/api/auth/logout', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      bearer: userASessionToken,
      deviceToken: deviceAToken,
    });
    assert.equal(logoutA.status, 200);

    // Device B still blocked after Device A logged out
    const loginBAgain = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      body: { code: keyCode },
    });
    assert.equal(loginBAgain.status, 403);

    // Device A can re-login using its signed deviceToken
    const reloginA = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      deviceToken: deviceAToken,
      body: { code: keyCode },
    });
    assert.equal(reloginA.status, 200);
    userASessionToken = reloginA.json.sessionToken;

    // Admin manually unbinds key -> Device B can now bind
    const unbind = await callApi(`/api/admin/keys/${keyId}/unbind`, {
      method: 'POST',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
    });
    assert.equal(unbind.status, 200);

    // Previous session on Device A is now invalid
    const meA = await callApi('/api/user/me', {
      bearer: userASessionToken,
      deviceToken: deviceAToken,
    });
    assert.equal(meA.status, 401);

    const loginBNow = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      body: { code: keyCode },
    });
    assert.equal(loginBNow.status, 200);
    deviceAToken = loginBNow.json.deviceToken;
    userASessionToken = loginBNow.json.sessionToken;
  });

  // 5. Subscription Resolution (Empty -> 404, Configured -> 200, Disabled Server/Feature -> 403)
  await test('Subscription resolve returns SUBSCRIPTION NOT AVAILABLE when empty, and resolves happ://add/ once configured', async () => {
    const pref = await callApi('/api/user/preferences', {
      method: 'PATCH',
      origin: 'https://primewirepro.pages.dev',
      bearer: userASessionToken,
      deviceToken: deviceAToken,
      body: { selectedServerId: 'singapore', activeFeatureId: 'aim_point' },
    });
    assert.equal(pref.status, 200);

    // Empty slot -> 404 SUBSCRIPTION NOT AVAILABLE
    const emptyRes = await callApi('/api/subscription/resolve', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      bearer: userASessionToken,
      deviceToken: deviceAToken,
      body: { serverId: 'singapore', featureId: 'aim_point' },
    });
    assert.equal(emptyRes.status, 404);
    assert.equal(emptyRes.json.error, 'SUBSCRIPTION NOT AVAILABLE');

    // Admin configures Singapore AIM POINT URL and enables it
    const saveUrl = await callApi('/api/admin/subscription-urls/singapore__aim_point', {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { url: 'https://example.invalid/sub/sg-aim', enabled: true },
    });
    assert.equal(saveUrl.status, 200);

    // Unauthorized request cannot resolve subscription URL
    const unauthResolve = await callApi('/api/subscription/resolve', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      body: { serverId: 'singapore', featureId: 'aim_point' },
    });
    assert.equal(unauthResolve.status, 401);

    // Authorized request receives happDeepLink
    const okResolve = await callApi('/api/subscription/resolve', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      bearer: userASessionToken,
      deviceToken: deviceAToken,
      body: { serverId: 'singapore', featureId: 'aim_point' },
    });
    assert.equal(okResolve.status, 200);
    assert.equal(okResolve.json.happDeepLink, 'happ://add/https://example.invalid/sub/sg-aim');

    // Disabling feature denies access
    const disableFeat = await callApi('/api/admin/features/aim_point', {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { enabled: false },
    });
    assert.equal(disableFeat.status, 200);

    const deniedResolve = await callApi('/api/subscription/resolve', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      bearer: userASessionToken,
      deviceToken: deviceAToken,
      body: { serverId: 'singapore', featureId: 'aim_point' },
    });
    assert.equal(deniedResolve.status, 403);

    // Re-enable feature
    await callApi('/api/admin/features/aim_point', {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { enabled: true },
    });
  });

  // 6. Key Expiration, Suspension & Universal Code Multi-Device
  await test('Suspended and expired keys lose access immediately', async () => {
    const susp = await callApi(`/api/admin/keys/${keyId}/status`, {
      method: 'POST',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { status: 'suspended' },
    });
    assert.equal(susp.status, 200);

    const me = await callApi('/api/user/me', {
      bearer: userASessionToken,
      deviceToken: deviceAToken,
    });
    assert.equal(me.status, 401);

    // Create an already-expired key
    const pastIso = new Date(Date.now() - 60_000).toISOString();
    const expiredKey = await callApi('/api/admin/keys', {
      method: 'POST',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        count: 1,
        customExpiresAt: pastIso,
      },
    });
    assert.equal(expiredKey.status, 201);
    const expLogin = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      body: { code: expiredKey.json.created[0].key_code },
    });
    assert.equal(expLogin.status, 403);
  });

  await test('Universal public code allows multiple devices and stops access when suspended', async () => {
    const uCreate = await callApi('/api/admin/universal-codes', {
      method: 'POST',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        code: 'EVENT-PASS-2026',
        durationSeconds: 3600,
      },
    });
    assert.equal(uCreate.status, 201);
    const uId = uCreate.json.id;

    // Two distinct devices sign in simultaneously
    const d1 = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      userAgent: 'Android Device 1',
      body: { code: 'EVENT-PASS-2026' },
    });
    const d2 = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      userAgent: 'iPhone Device 2',
      body: { code: 'EVENT-PASS-2026' },
    });
    assert.equal(d1.status, 200);
    assert.equal(d2.status, 200);
    assert.equal(d1.json.authType, 'universal_code');
    assert.equal(d2.json.authType, 'universal_code');

    // Suspend universal code -> both sessions fail
    await callApi(`/api/admin/universal-codes/${uId}`, {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { status: 'suspended' },
    });

    const checkD1 = await callApi('/api/user/me', {
      bearer: d1.json.sessionToken,
      deviceToken: d1.json.deviceToken,
    });
    assert.equal(checkD1.status, 401);
  });

  // 7. Maintenance Mode
  await test('Maintenance mode blocks public users (503) while keeping admin dashboard online', async () => {
    const on = await callApi('/api/admin/settings', {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: {
        maintenanceMode: true,
        maintenanceMessage: 'Scheduled server upgrade in progress.',
      },
    });
    assert.equal(on.status, 200);

    const pubStatus = await callApi('/api/public/status');
    assert.equal(pubStatus.status, 200);
    assert.equal(pubStatus.json.maintenanceMode, true);
    assert.equal(pubStatus.json.maintenanceMessage, 'Scheduled server upgrade in progress.');

    const pubLogin = await callApi('/api/auth/login', {
      method: 'POST',
      origin: 'https://primewirepro.pages.dev',
      body: { code: 'PMWR-AAAA-BBBB-CCCC' },
    });
    assert.equal(pubLogin.status, 503);

    // Admin overview remains operational
    const admOverview = await callApi('/api/admin/overview', { bearer: superToken });
    assert.equal(admOverview.status, 200);

    // Turn maintenance back off
    await callApi('/api/admin/settings', {
      method: 'PATCH',
      bearer: superToken,
      origin: 'https://primewirepro-dashboard.pages.dev',
      body: { maintenanceMode: false },
    });
  });

  db.sqlite.close();
  console.log(`\nALL ${passed} BACKEND & SECURITY TESTS PASSED`);
}

runTests().catch((err) => {
  console.error('TEST FAILURE:', err);
  process.exit(1);
});
