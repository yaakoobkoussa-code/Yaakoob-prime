# PRIME WIRE PRO — Cloudflare Free Hosting Deployment Guide

This platform runs on **100% Cloudflare free-tier services** with zero purchased domains required:
1. **Cloudflare D1** — Relational SQLite database (`workers/migrations/0001_initial.sql`)
2. **Cloudflare Workers** — Protected REST API (`workers/api/src/index.ts`)
3. **Cloudflare Pages #1 (Public Website)** — User portal (`dist/` built via `npm run build:public`)
4. **Cloudflare Pages #2 (Admin Dashboard)** — Isolated administrator console (`dist-admin/` built via `npm run build:admin`)

---

## 1. Prerequisites

```bash
npm install
npm install -g wrangler
wrangler login
```

Verify authentication:
```bash
wrangler whoami
```

---

## 2. Create & Migrate Cloudflare D1 Database (Free Plan)

Create the database:
```bash
wrangler d1 create primewirepro-db
```

Copy the returned `database_id` into `workers/wrangler.toml`:
```toml
[[d1_databases]]
binding = "DB"
database_name = "primewirepro-db"
database_id = "<YOUR_D1_DATABASE_ID>"
migrations_dir = "migrations"
```

Apply the initial schema and seed data (5 servers, 2 features, 10 empty subscription URLs, RBAC roles/permissions, and website settings):
```bash
cd workers
wrangler d1 execute primewirepro-db --remote --file=./migrations/0001_initial.sql
```

Confirm seeded tables:
```bash
wrangler d1 execute primewirepro-db --remote --command="SELECT id, name, enabled FROM servers;"
wrangler d1 execute primewirepro-db --remote --command="SELECT id, title, enabled FROM features;"
wrangler d1 execute primewirepro-db --remote --command="SELECT COUNT(*) AS url_slots FROM subscription_urls;"
```

---

## 3. Configure Secrets & Deploy the Backend API Worker

Generate two strong random secrets (at least 32 characters each):
```bash
openssl rand -hex 32   # SESSION_SECRET
openssl rand -hex 24   # BOOTSTRAP_SETUP_SECRET
```

Store them securely in Cloudflare Workers Secrets (never committed to Git):
```bash
cd workers
wrangler secret put SESSION_SECRET
wrangler secret put BOOTSTRAP_SETUP_SECRET
```

Verify `PUBLIC_ORIGIN` and `ADMIN_ORIGIN` inside `workers/wrangler.toml` match your chosen Cloudflare Pages URLs (see Step 4 below before finalizing CORS):
```toml
[vars]
PUBLIC_ORIGIN = "https://primewirepro.pages.dev"
ADMIN_ORIGIN = "https://primewirepro-dashboard.pages.dev"
ALLOW_LOCAL_DEV_ORIGINS = "false"
```

Deploy the Worker:
```bash
cd workers
wrangler deploy
```

Note your deployed Worker URL (for example: `https://primewirepro-api.<your-subdomain>.workers.dev`).

Verify health:
```bash
curl https://primewirepro-api.<your-subdomain>.workers.dev/api/health
```

---

## 4. Check `.pages.dev` Subdomain Availability & Deploy Separate Frontends

Because `.pages.dev` subdomains are globally unique across Cloudflare accounts, check availability before deploying:

1. Check via HTTP or Wrangler project creation:
   ```bash
   curl -I https://primewirepro.pages.dev
   curl -I https://primewirepro-dashboard.pages.dev
   ```
   - Alternatively, creating the project with `wrangler pages project create <name>` immediately confirms whether the `<name>.pages.dev` subdomain is available on your account.
   - If `primewirepro.pages.dev` or `primewirepro-dashboard.pages.dev` is already taken by another Cloudflare user, select an available free `.pages.dev` name such as:
     - Public site: `primewirepro-app.pages.dev` or `primewire-portal.pages.dev`
     - Admin dashboard: `primewirepro-admin.pages.dev` or `pwpro-console-adm.pages.dev`
   - Update `PUBLIC_ORIGIN` and `ADMIN_ORIGIN` in `workers/wrangler.toml` to match your actual `.pages.dev` URLs and run `wrangler deploy` again so CORS and CSRF protections match.

### A. Build & Deploy Public Website (`dist/`)
Set `VITE_API_BASE_URL` to your deployed Worker URL during build:
```bash
VITE_API_BASE_URL="https://primewirepro-api.<your-subdomain>.workers.dev" npm run build:public
wrangler pages project create primewirepro --production-branch=main
wrangler pages deploy dist --project-name=primewirepro
```

### B. Build & Deploy Separate Admin Dashboard (`dist-admin/`)
```bash
VITE_API_BASE_URL="https://primewirepro-api.<your-subdomain>.workers.dev" npm run build:admin
wrangler pages project create primewirepro-dashboard --production-branch=main
wrangler pages deploy dist-admin --project-name=primewirepro-dashboard
```

Confirm strict separation: the `dist/` bundle contains zero admin components, zero `/api/admin` routes, and zero admin login forms.

---

## 5. Create the Initial `SUPER_ADMIN` Account (First Boot)

1. Open your deployed Admin Dashboard (`https://primewirepro-dashboard.pages.dev`).
2. Because the `administrators` table starts empty, the login page prompts once for:
   - **Bootstrap Setup Secret** (the `BOOTSTRAP_SETUP_SECRET` you set in Step 3)
   - **Username**, **Email**, and **Password** (minimum 10 characters)
3. Alternatively, initialize via `curl`:
   ```bash
   curl -X POST https://primewirepro-api.<your-subdomain>.workers.dev/api/admin/bootstrap \
     -H "Content-Type: application/json" \
     -H "X-Bootstrap-Secret: YOUR_BOOTSTRAP_SETUP_SECRET" \
     -d '{"username":"superadmin","email":"admin@example.com","password":"ReplaceWithStrongPassword!123"}'
   ```
4. As soon as the first `SUPER_ADMIN` exists, the `/api/admin/bootstrap` endpoint permanently locks (`403 Administrator accounts already initialized`).
5. Sign in to the Admin Dashboard, open **Subscription URLs (10)** to add and enable your Happ subscription endpoints, and use **Key Management** or **Universal Codes** to issue user access.

---

## 6. Cloudflare Free Plan Limits & Architecture Compatibility

| Service | Cloudflare Free Plan Limit | How PRIME WIRE PRO Fits Safely |
|---|---|---|
| **Cloudflare Pages** | Unlimited bandwidth, unlimited sites, 500 builds/month, 20,000 files/site | Two lightweight React/Vite SPAs (~10 files each) fit well within build and file quotas with zero bandwidth fees. |
| **Cloudflare Workers** | 100,000 requests/day, 10 ms CPU time per invocation | All auth/session checks use compact D1 indexed lookups and WebCrypto PBKDF2/HMAC (< 2–4 ms CPU). Periodic server polling is minimized. |
| **Cloudflare D1** | 5 GB storage, 5,000,000 rows read/day, 100,000 rows written/day | Indexed token hashes (`token_hash`, `key_code`) ensure single-row reads per API call; security logs & sessions fit comfortably under daily write quotas. |
| **Maintenance & Rate Limiting** | Stored in D1 (`website_settings`, `rate_limits`) | Requires zero paid Durable Objects or KV add-ons. |

### Optional Paid Upgrades Not Required
- No paid custom domain required (`.pages.dev` + `.workers.dev` provide automatic HTTPS TLS certificates).
- If future traffic exceeds **100,000 Worker requests/day** or **100,000 D1 writes/day**, upgrading to the **Workers Paid ($5/month)** tier immediately expands limits without code changes.

---

## 7. Security & Device Binding Notes

- **Permanent Device Binding (Web/PWA Browser Limitation):** Web browsers and PWAs cannot access hardware IMEI/Android ID directly. When a user activates an individual product key (`PMWR-XXXX-XXXX-XXXX`), the Worker issues an **HMAC-signed server device credential** stored in an `HttpOnly` cookie and `localStorage` (`X-Device-Token`). Another browser/phone without that credential is rejected (`403 DEVICE_MISMATCH`) unless an administrator manually runs **Unbind Device**. Note that if the original user wipes all browser storage/cookies, they will need an admin unbind to re-bind cleanly (which also prevents unauthorized sharing via browser clearing).
- **Private URL Protection:** Subscription URLs are stored exclusively in D1 and never included in public bundles or unauthenticated responses. Only authenticated, active, unbound-conflict-free, feature-permitted sessions receive a `happDeepLink` from `POST /api/subscription/resolve`.
